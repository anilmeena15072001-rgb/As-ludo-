# Room Ludo

Room Ludo is a private room-code multiplayer Ludo game for quick browser game nights.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/room-ludo/src/pages/home.tsx` — create/join room entry screen.
- `artifacts/room-ludo/src/pages/room.tsx` — lobby, polling, match controls, and win state.
- `artifacts/room-ludo/src/components/ludo.tsx` — board, dice, player, and room UI primitives.
- `artifacts/api-server/src/routes/rooms.ts` — room lifecycle and in-memory game rules.
- `lib/api-spec/openapi.yaml` — source of truth for the room API contract.

## Architecture decisions

- Room state is held in the API server memory for the first playable version; restarting the server closes active rooms.
- The browser polls room state every 2.5 seconds so multiple tabs can play without an additional realtime service.
- Player identity is stored in localStorage per room code, with no account required.
- The Ludo board is a deliberately simplified visual board; the server remains authoritative for turn, dice, and token state.

## Product

- Create a 4-character private room code or join one shared by a friend.
- See the waiting lobby, copy the room code, and start once at least two players are present.
- Roll, select tokens, pass turns, and see a winner across connected browser sessions.

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- The API server must be running at `/api` for create/join and room polling to work.
- Manual Vite builds need `PORT` and `BASE_PATH`; managed workflows provide them automatically.
- Enable Firebase Phone provider and add the app's preview/published domains to Firebase Authentication authorized domains.
- Deploy `artifacts/room-ludo/firebase.database.rules.json` to the `ludo-zone-d7b9f` Realtime Database before using wallet/KYC data outside local development.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
