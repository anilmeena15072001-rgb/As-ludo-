import { ArrowRight, Clock3, Loader2, RefreshCw, ShieldCheck, Swords, Users } from 'lucide-react';
import { useEffect, useState } from 'react';
import {
  getGetChallengesQueryKey,
  useCreateChallenge,
  useGetChallenges,
  useJoinChallenge,
} from '@workspace/api-client-react';
import type { Challenge, Room } from '@workspace/api-client-react';
import { useQueryClient } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { LogoMark } from '@/components/ludo';
import { PhoneLogin, useFirebaseAuth } from '@/components/auth';
import { AccountBar } from '@/components/account';

function formatRupees(value: number) {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 2,
  }).format(value);
}

function postedLabel(timestamp: number) {
  const elapsedMinutes = Math.max(0, Math.floor((Date.now() - timestamp) / 60_000));
  if (elapsedMinutes < 1) return 'Posted just now';
  if (elapsedMinutes < 60) return `Posted ${elapsedMinutes}m ago`;
  const elapsedHours = Math.floor(elapsedMinutes / 60);
  if (elapsedHours < 24) return `Posted ${elapsedHours}h ago`;
  return 'Posted over a day ago';
}

export default function Home() {
  const { user, loading: authLoading } = useFirebaseAuth();
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const [name, setName] = useState('');
  const [stake, setStake] = useState('');
  const [selectedChallengeId, setSelectedChallengeId] = useState<string | null>(null);
  const [acceptedStake, setAcceptedStake] = useState(false);
  const [formError, setFormError] = useState('');
  const createChallenge = useCreateChallenge();
  const joinChallenge = useJoinChallenge();
  const challengeList = useGetChallenges({
    query: {
      enabled: !!user,
      queryKey: getGetChallengesQueryKey(),
      refetchInterval: 3000,
      refetchOnWindowFocus: true,
    },
  });

  useEffect(() => {
    setAcceptedStake(false);
    setFormError('');
  }, [selectedChallengeId]);

  function enterMatch(room: Room, playerName: string) {
    const player = room.youPlayerId
      ? room.players.find((candidate) => candidate.id === room.youPlayerId)
      : room.players.find((candidate) => candidate.name === playerName);
    localStorage.setItem(`room-ludo-player-${room.code}`, player?.id ?? room.youPlayerId ?? '');
    localStorage.setItem(`room-ludo-name-${room.code}`, playerName);
    setLocation(`/room/${room.code}`);
  }

  function submitChallenge(event: React.FormEvent) {
    event.preventDefault();
    const cleanName = name.trim();
    const betAmount = Number(stake);
    setFormError('');

    if (cleanName.length < 2) {
      setFormError('Enter a display name with at least two characters.');
      return;
    }
    if (
      stake.trim() === '' ||
      !Number.isFinite(betAmount) ||
      betAmount <= 0 ||
      Math.abs(betAmount * 100 - Math.round(betAmount * 100)) > 0.000001
    ) {
      setFormError('Enter a stake greater than ₹0 with up to two decimal places.');
      return;
    }

    createChallenge.mutate(
      { data: { playerName: cleanName, betAmount } },
      {
        onSuccess: (room) => enterMatch(room, cleanName),
        onError: (error) => setFormError(error.message || 'The challenge could not be posted. Try again.'),
      },
    );
  }

  function joinSelectedChallenge(challenge: Challenge) {
    const cleanName = name.trim();
    setFormError('');
    if (cleanName.length < 2) {
      setFormError('Enter a display name before joining a challenge.');
      return;
    }
    if (!acceptedStake) {
      setFormError('Confirm the stake and payout terms before joining.');
      return;
    }

    joinChallenge.mutate(
      {
        challengeId: challenge.id,
        data: { playerName: cleanName, acceptedBetAmount: challenge.betAmount },
      },
      {
        onSuccess: (room) => {
          void queryClient.invalidateQueries({ queryKey: getGetChallengesQueryKey() });
          enterMatch(room, cleanName);
        },
        onError: (error) => setFormError(error.message || 'That challenge is no longer open. Refresh the list.'),
      },
    );
  }

  if (authLoading) {
    return <main className="game-noise grid min-h-[100dvh] place-items-center text-[#202538]"><div className="font-display text-2xl font-bold">Checking your sign-in…</div></main>;
  }
  if (!user) return <PhoneLogin />;

  const challenges = challengeList.data ?? [];
  const nameIsValid = name.trim().length >= 2;

  return (
    <main className="game-noise min-h-[100dvh] overflow-hidden text-[#202538]">
      <header className="mx-auto flex max-w-7xl items-center justify-between px-5 py-6 sm:px-8">
        <LogoMark />
        <div className="flex items-center gap-2">
          <div className="hidden items-center gap-2 text-xs font-bold uppercase tracking-[.16em] text-[#7f7b70] sm:flex"><span className="h-2 w-2 rounded-full bg-[#3a9b9b]" />Open challenges</div>
          <AccountBar showAdminKyc={false} />
        </div>
      </header>

      <div className="mx-auto max-w-7xl px-5 pb-12 pt-5 sm:px-8 sm:pt-8">
        <div className="mb-8 flex flex-col justify-between gap-4 border-b border-[#d9d1bd] pb-7 sm:flex-row sm:items-end">
          <div>
            <div className="mb-3 inline-flex items-center gap-2 rounded-full border-2 border-[#202538] bg-[#f6d85a] px-4 py-2 text-xs font-bold uppercase tracking-[.14em] ludo-shadow-sm"><Swords className="h-4 w-4" />Head-to-head matchmaking</div>
            <h1 className="font-display text-4xl font-bold tracking-[-.055em] sm:text-5xl">Open challenges</h1>
            <p className="mt-2 max-w-2xl text-sm leading-relaxed text-[#68675e]">Post a stake and wait for another player to join. Challenges are public; no room codes to share.</p>
          </div>
          <div className="flex items-center gap-2 text-xs font-bold text-[#7f7b70]"><Users className="h-4 w-4 text-[#3a9b9b]" />1v1 · 2 players</div>
        </div>

        <label className="mb-6 block max-w-xl rounded-2xl border-2 border-[#d9d1bd] bg-[#fffaf0] p-4">
          <span className="mb-2 block text-xs font-bold uppercase tracking-[.16em] text-[#7f7b70]">Your display name</span>
          <input
            value={name}
            onChange={(event) => setName(event.target.value)}
            maxLength={20}
            placeholder="How should other players call you?"
            className="w-full rounded-xl border-2 border-[#d9d1bd] bg-[#fffdf6] px-4 py-3 text-base font-medium outline-none transition-colors placeholder:text-[#aaa393] focus:border-[#ee604c]"
            data-testid="input-player-name"
          />
        </label>

        {formError && <div className="mb-6 rounded-xl border border-[#ee604c]/40 bg-[#fff0e7] px-4 py-3 text-sm font-medium text-[#b94b3c]" role="alert" data-testid="status-challenge-error">{formError}</div>}

        <div className="grid items-start gap-6 lg:grid-cols-[minmax(300px,.82fr)_minmax(0,1.18fr)]">
          <section className="rounded-[28px] border-[3px] border-[#202538] bg-[#fffaf0] p-5 ludo-shadow sm:p-7">
            <div className="mb-6">
              <div className="font-display text-3xl font-bold tracking-[-.04em]">Create a challenge</div>
              <p className="mt-2 text-sm leading-relaxed text-[#7f7b70]">Set the amount each player stakes. Your open challenge will appear in the list for an opponent.</p>
            </div>
            <form onSubmit={submitChallenge} className="space-y-4">
              <label className="block">
                <span className="mb-2 block text-xs font-bold uppercase tracking-[.16em] text-[#7f7b70]">Stake per player / ₹</span>
                <input
                  value={stake}
                  onChange={(event) => setStake(event.target.value)}
                  type="number"
                  min="0.01"
                  step="0.01"
                  inputMode="decimal"
                  placeholder="For example, 100"
                  required
                  className="w-full rounded-2xl border-2 border-[#d9d1bd] bg-[#fffdf6] px-4 py-4 text-base font-medium outline-none transition-colors placeholder:text-[#aaa393] focus:border-[#ee604c]"
                  data-testid="input-challenge-stake"
                />
              </label>
              <div className="rounded-2xl bg-[#f0e8d4] p-4 text-xs leading-relaxed text-[#68675e]">
                Both players stake the listed amount when the host starts. The winner receives 95% of the pot; 5% is recorded as commission. Unstarted stakes are not collected.
              </div>
              <div className="flex items-start gap-2 text-xs leading-relaxed text-[#b94b3c]"><ShieldCheck className="mt-0.5 h-4 w-4 shrink-0" />Use real-money wagers only where permitted by local law.</div>
              <button
                type="submit"
                disabled={createChallenge.isPending}
                className="btn-press flex w-full items-center justify-center rounded-2xl bg-[#ee604c] px-5 py-4 text-base font-bold text-[#fffaf0] ludo-shadow-sm disabled:cursor-wait disabled:opacity-70"
                data-testid="button-create-challenge"
              >
                {createChallenge.isPending ? <Loader2 className="mr-2 h-5 w-5 animate-spin" /> : <ArrowRight className="mr-2 h-5 w-5" />}
                {createChallenge.isPending ? 'Posting challenge…' : 'Post challenge'}
              </button>
            </form>
            <div className="mt-5 flex items-center gap-2 text-xs font-medium text-[#969082]"><Clock3 className="h-4 w-4" />Open challenges expire after 24 hours without activity. Stakes are collected only when the host starts.</div>
          </section>

          <section className="rounded-[28px] border-[3px] border-[#202538] bg-[#fffaf0] p-5 ludo-shadow sm:p-7">
            <div className="mb-5 flex items-start justify-between gap-4">
              <div>
                <div className="font-display text-3xl font-bold tracking-[-.04em]">Join a challenge</div>
                <p className="mt-2 text-sm leading-relaxed text-[#7f7b70]">Choose an open stake and review its payout before joining.</p>
              </div>
              <button
                type="button"
                onClick={() => void challengeList.refetch()}
                disabled={challengeList.isFetching}
                className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border-2 border-[#d9d1bd] bg-[#fffdf6] text-[#7f7b70] transition-transform hover:rotate-45 disabled:opacity-60"
                aria-label="Refresh challenges"
                data-testid="button-refresh-challenges"
              >
                <RefreshCw className={`h-4 w-4 ${challengeList.isFetching ? 'animate-spin' : ''}`} />
              </button>
            </div>

            {challengeList.isLoading ? (
              <div className="rounded-2xl border-2 border-dashed border-[#d9d1bd] p-8 text-center text-sm font-medium text-[#7f7b70]">Finding open challenges…</div>
            ) : challengeList.isError ? (
              <div className="rounded-2xl border-2 border-[#ee604c]/30 bg-[#fff0e7] p-5 text-sm font-medium text-[#b94b3c]">
                The challenge list could not be loaded.
                <button type="button" onClick={() => void challengeList.refetch()} className="ml-2 font-bold underline">Try again</button>
              </div>
            ) : challenges.length === 0 ? (
              <div className="rounded-2xl border-2 border-dashed border-[#d9d1bd] p-8 text-center">
                <div className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-[#f0e8d4] text-[#3a9b9b]"><Swords className="h-6 w-6" /></div>
                <div className="mt-3 font-bold">No open challenges yet</div>
                <p className="mt-1 text-sm text-[#7f7b70]">Post the first one, or refresh in a moment.</p>
              </div>
            ) : (
              <div className="space-y-3" data-testid="list-open-challenges">
                {challenges.map((challenge) => (
                  <ChallengeCard
                    key={challenge.id}
                    challenge={challenge}
                    selected={selectedChallengeId === challenge.id}
                    acceptedStake={acceptedStake}
                    nameIsValid={nameIsValid}
                    joinPending={joinChallenge.isPending}
                    onSelect={() => {
                      setFormError('');
                      setSelectedChallengeId(challenge.id === selectedChallengeId ? null : challenge.id);
                    }}
                    onAcceptChange={setAcceptedStake}
                    onJoin={() => joinSelectedChallenge(challenge)}
                  />
                ))}
              </div>
            )}
            <div className="mt-5 flex items-center gap-2 text-xs font-medium text-[#969082]"><RefreshCw className="h-3.5 w-3.5" />List refreshes automatically every few seconds.</div>
          </section>
        </div>
      </div>

      <footer className="mx-auto flex max-w-7xl items-center justify-between border-t border-[#d9d1bd] px-5 py-5 text-[11px] font-bold uppercase tracking-[.16em] text-[#969082] sm:px-8"><span>Roll well. Talk louder.</span><span>Room Ludo / 2025</span></footer>
    </main>
  );
}

function ChallengeCard({
  challenge,
  selected,
  acceptedStake,
  nameIsValid,
  joinPending,
  onSelect,
  onAcceptChange,
  onJoin,
}: {
  challenge: Challenge;
  selected: boolean;
  acceptedStake: boolean;
  nameIsValid: boolean;
  joinPending: boolean;
  onSelect: () => void;
  onAcceptChange: (accepted: boolean) => void;
  onJoin: () => void;
}) {
  const totalPot = challenge.betAmount * 2;
  const commission = Math.round(totalPot * 100 * 0.05) / 100;
  const winnerPayout = totalPot - commission;

  return (
    <article className="rounded-2xl border-2 border-[#d9d1bd] bg-[#fffdf6] p-4" data-testid="card-open-challenge">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <div className="font-display text-xl font-bold">{challenge.isMine ? 'Your challenge' : `${challenge.hostName}’s challenge`}</div>
          <div className="mt-1 text-xs font-medium text-[#969082]">{postedLabel(challenge.createdAt)} · 1 of 2 players</div>
        </div>
        <div className="rounded-xl bg-[#f6d85a] px-3 py-2 text-right">
          <div className="text-[10px] font-bold uppercase tracking-[.12em] text-[#68675e]">Stake each</div>
          <div className="font-display text-lg font-bold">{formatRupees(challenge.betAmount)}</div>
        </div>
      </div>
      <div className="mt-4 grid grid-cols-2 gap-2 rounded-xl bg-[#f0e8d4] p-3 text-xs">
        <div><div className="text-[#7f7b70]">Total pot</div><strong className="mt-1 block text-sm text-[#202538]">{formatRupees(totalPot)}</strong></div>
        <div><div className="text-[#7f7b70]">Winner receives</div><strong className="mt-1 block text-sm text-[#202538]">{formatRupees(winnerPayout)}</strong></div>
      </div>

      {challenge.isMine ? (
        <div className="mt-4 rounded-xl bg-[#e7f5f1] px-3 py-3 text-sm font-bold text-[#276c6c]">Waiting for an opponent to join.</div>
      ) : (
        <>
          <button
            type="button"
            onClick={onSelect}
            disabled={joinPending || !nameIsValid}
            className="mt-4 flex w-full items-center justify-center rounded-xl bg-[#202538] px-4 py-3 text-sm font-bold text-[#fffaf0] disabled:cursor-not-allowed disabled:opacity-50"
            data-testid="button-review-challenge"
          >
            {selected ? 'Close details' : nameIsValid ? 'Review and join' : 'Enter your name to join'}
          </button>
          {selected && (
            <div className="mt-4 space-y-3 border-t border-[#e2dccb] pt-4">
              <p className="text-xs leading-relaxed text-[#7f7b70]">
                Both players stake {formatRupees(challenge.betAmount)}. The pot is {formatRupees(totalPot)}; after 5% commission, the winner receives {formatRupees(winnerPayout)}. Stakes are collected when the host starts.
              </p>
              <label className="flex cursor-pointer items-start gap-2 text-xs font-semibold leading-relaxed text-[#202538]">
                <input type="checkbox" checked={acceptedStake} onChange={(event) => onAcceptChange(event.target.checked)} className="mt-0.5 accent-[#ee604c]" />
                I agree to this stake and payout split.
              </label>
              <button
                type="button"
                onClick={onJoin}
                disabled={!acceptedStake || joinPending}
                className="flex w-full items-center justify-center rounded-xl bg-[#ee604c] px-4 py-3 text-sm font-bold text-[#fffaf0] disabled:cursor-not-allowed disabled:opacity-50"
                data-testid="button-join-challenge"
              >
                {joinPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <ArrowRight className="mr-2 h-4 w-4" />}
                {joinPending ? 'Joining…' : 'Accept and join'}
              </button>
            </div>
          )}
        </>
      )}
    </article>
  );
}