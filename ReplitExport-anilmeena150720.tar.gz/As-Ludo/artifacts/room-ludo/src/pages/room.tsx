import { Check, ChevronRight, Clock3, Loader2, RefreshCw, RotateCw, Shield, Trophy, Users } from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { getGetRoomQueryKey, useDeleteRoom, useGetRoom, useMoveToken, useRollDice, useStartRoom } from '@workspace/api-client-react';
import type { Player, Room } from '@workspace/api-client-react';
import { useLocation, useParams } from 'wouter';
import { Avatar, Dice, ErrorNotice, LeaveButton, LudoBoard, LogoMark, PlayerRow, SectionLabel } from '@/components/ludo';
import { PhoneLogin, useFirebaseAuth } from '@/components/auth';
import { AccountBar } from '@/components/account';

function getHttpStatus(error: unknown): number | null {
  if (typeof error !== 'object' || error === null || !('status' in error)) return null;
  const status = (error as { status?: unknown }).status;
  return typeof status === 'number' ? status : null;
}

export default function RoomPage() {
  const { user, loading: authLoading } = useFirebaseAuth();
  const { code = '' } = useParams<{ code: string }>();
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const [playerId, setPlayerId] = useState(() => localStorage.getItem(`room-ludo-player-${code}`) ?? '');
  const [selectedToken, setSelectedToken] = useState<string | null>(null);
  const [rolling, setRolling] = useState(false);
  const [actionError, setActionError] = useState('');
  const roomQuery = useGetRoom(code, { query: { enabled: !!user, queryKey: getGetRoomQueryKey(code), refetchInterval: 2500, refetchOnWindowFocus: true } });
  const startRoom = useStartRoom();
  const deleteRoom = useDeleteRoom();
  const rollDice = useRollDice();
  const moveToken = useMoveToken();
  const room = roomQuery.data;
  const me = useMemo(() => room?.players.find((player) => player.id === playerId), [room, playerId]);
  const currentPlayer = useMemo(() => room?.players.find((player) => player.id === room.currentPlayerId), [room]);
  const isHost = room?.hostId === playerId;
  const isMyTurn = room?.currentPlayerId === playerId;
  const busy = startRoom.isPending || deleteRoom.isPending || rollDice.isPending || moveToken.isPending;

  useEffect(() => {
    if (!room?.youPlayerId || room.youPlayerId === playerId) return;
    setPlayerId(room.youPlayerId);
    localStorage.setItem(`room-ludo-player-${code}`, room.youPlayerId);
  }, [room?.youPlayerId, playerId, code]);

  function patchRoom(updated: typeof room) {
    if (updated) queryClient.setQueryData(getGetRoomQueryKey(code), updated);
  }

  function startMatch() {
    if (!playerId) return;
    setActionError('');
    startRoom.mutate({ code, data: { playerId } }, { onSuccess: patchRoom, onError: (error) => setActionError(error.message) });
  }

  function roll() {
    if (!playerId || !isMyTurn) return;
    setActionError('');
    setRolling(true);
    rollDice.mutate({ code, data: { playerId } }, { onSuccess: (updated) => { patchRoom(updated); window.setTimeout(() => setRolling(false), 380); }, onError: (error) => { setRolling(false); setActionError(error.message); } });
  }

  function chooseToken(key: string, tokenIndex: number) {
    if (!playerId || !isMyTurn || room?.dice === null) return;
    setSelectedToken(key);
    setActionError('');
    moveToken.mutate({ code, data: { playerId, tokenIndex } }, { onSuccess: (updated) => { patchRoom(updated); setSelectedToken(null); }, onError: (error) => { setSelectedToken(null); setActionError(error.message); } });
  }

  function leave() {
    if (!playerId) { setLocation('/'); return; }
    deleteRoom.mutate({ code, data: { playerId } }, { onSuccess: () => { localStorage.removeItem(`room-ludo-player-${code}`); localStorage.removeItem(`room-ludo-name-${code}`); setLocation('/'); }, onError: (error) => setActionError(error.message) });
  }

  if (authLoading) return <div className="game-noise"><LoadingSkeleton /></div>;
  if (!user) return <PhoneLogin compact />;
  if (roomQuery.isLoading) return <div className="game-noise"><LoadingSkeleton /></div>;
  if (roomQuery.isError || !room) {
    const status = getHttpStatus(roomQuery.error);
    const message = status === 403
      ? 'This match is not linked to your account. Join through an open challenge on the home board.'
      : status === 404
        ? 'We could not find this match. It may have expired or closed. Return to the open challenge board to join an active match.'
        : roomQuery.error
          ? 'We could not load this match. Check your connection and try again.'
          : 'This match is no longer available. Return to the open challenge board to join an active match.';
    return (
      <ErrorNotice
        message={message}
        onRetry={() => void roomQuery.refetch()}
        onBack={() => setLocation('/')}
      />
    );
  }
  if (!room.youPlayerId) return <ErrorNotice message="This signed-in account is not a player in this match." onRetry={() => setLocation('/')} />;

  const statusText = room.status === 'waiting' ? room.wagerStatus === 'collecting' ? 'Collecting stakes' : room.players.length >= 2 ? 'Opponent joined' : 'Waiting for opponent' : room.status === 'finished' ? 'Match complete' : room.status === 'cancelled' ? 'Match canceled' : isMyTurn ? 'Your turn' : `${currentPlayer?.name ?? 'A player'} is up`;
  return (
    <main className="game-noise min-h-[100dvh] text-[#202538]">
      <header className="mx-auto flex max-w-[1440px] items-center justify-between px-5 py-5 sm:px-8">
        <LogoMark compact />
        <div className="flex flex-wrap items-center justify-end gap-2"><AccountBar /><button type="button" onClick={() => roomQuery.refetch()} disabled={roomQuery.isFetching} className="grid h-10 w-10 place-items-center rounded-xl border-2 border-[#d9d1bd] bg-[#fffaf0] text-[#7f7b70] transition-transform hover:rotate-45 disabled:opacity-60" data-testid="button-refresh-room" aria-label="Refresh match"><RefreshCw className="h-4 w-4" /></button><LeaveButton onClick={leave} pending={deleteRoom.isPending} /></div>
      </header>
      <div className="mx-auto max-w-[1440px] px-5 pb-10 sm:px-8">
        <div className="mb-6 border-b border-[#d9d1bd] pb-6">
          <div className="mb-3 flex items-center gap-2 text-[11px] font-bold uppercase tracking-[.2em] text-[#7f7b70]"><span className={`h-2.5 w-2.5 rounded-full ${room.status === 'playing' ? 'bg-[#ee604c] status-pulse' : 'bg-[#3a9b9b]'}`} />{statusText}</div>
          <h1 className="font-display text-4xl font-bold tracking-[-.055em] sm:text-5xl" data-testid="text-room-title">{room.status === 'waiting' ? 'Your challenge is almost ready.' : room.status === 'finished' ? 'That’s a wrap.' : room.status === 'cancelled' ? 'The match was canceled.' : 'The match is live.'}</h1>
          <div className="mt-3 text-sm font-semibold text-[#7f7b70]">Head-to-head match · {room.players.length} of 2 players</div>
        </div>
        {actionError && <div className="mb-5 flex items-center justify-between rounded-2xl border-2 border-[#ee604c]/40 bg-[#fff0e7] px-4 py-3 text-sm font-medium text-[#b94b3c]" data-testid="status-action-error"><span>{actionError}</span><button type="button" onClick={() => setActionError('')} data-testid="button-dismiss-error"><Check className="h-4 w-4" /></button></div>}
        {room.status === 'cancelled' ? <CancelledRoom room={room} /> : room.status === 'waiting' ? <Lobby room={room} playerId={playerId} isHost={!!isHost} onStart={startMatch} starting={startRoom.isPending} /> : <Match room={room} playerId={playerId} me={me} currentPlayer={currentPlayer} isMyTurn={!!isMyTurn} selectedToken={selectedToken} rolling={rolling || rollDice.isPending} onRoll={roll} onSelectToken={chooseToken} busy={busy} />}
      </div>
    </main>
  );
}

function Lobby({ room, playerId, isHost, onStart, starting }: { room: Room; playerId: string; isHost: boolean; onStart: () => void; starting: boolean }) {
  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_370px]">
      <section className="rounded-[28px] border-[3px] border-[#202538] bg-[#202538] p-5 text-[#fffaf0] ludo-shadow sm:p-8">
        <div className="flex h-full min-h-[460px] flex-col justify-between">
          <div><div className="mb-8 flex h-12 w-12 rotate-3 items-center justify-center rounded-2xl bg-[#f6d85a] text-2xl font-bold text-[#202538]"><Users className="h-6 w-6" /></div><h2 className="max-w-lg font-display text-4xl font-bold leading-[.95] tracking-[-.055em] sm:text-6xl">Open challenge.<br /><span className="text-[#f6d85a]">One opponent.</span></h2><p className="mt-5 max-w-md text-base leading-relaxed text-[#d1d0c7]">Your challenge is listed on the public board. Another player can join at the same stake, then the host can start the match.</p></div>
          <div className="mt-10 flex flex-wrap items-center gap-4"><div className="rounded-2xl border-2 border-[#f4efdf]/20 bg-[#fffaf0]/10 px-4 py-3"><div className="text-[10px] font-bold uppercase tracking-[.18em] text-[#aaa9a0]">Challenge status</div><div className="mt-1 font-bold text-[#f6d85a]">{room.players.length < 2 ? 'Open · awaiting opponent' : 'Opponent joined · ready'}</div></div><div className="text-sm font-medium text-[#aaa9a0]">{room.players.length < 2 ? 'Waiting for one opponent to join' : 'Both players are at the table'}</div></div>
        </div>
      </section>
      <aside className="rounded-[28px] border-[3px] border-[#202538] bg-[#fffaf0] p-5 ludo-shadow sm:p-6">
        <SectionLabel>At the table / {room.players.length} of 2</SectionLabel>
        <WagerCard room={room} />
        <div className="space-y-2">{room.players.map((player, index) => <PlayerRow key={player.id} player={player} index={index} isHost={player.id === room.hostId} isCurrent={player.id === playerId} />)}</div>
        {room.players.length < 2 && <div className="mt-3 flex items-center gap-3 rounded-2xl border border-dashed border-[#d9d1bd] px-3 py-4 text-sm font-medium text-[#969082]"><div className="grid h-8 w-8 place-items-center rounded-full bg-[#f0e8d4] text-[#969082]">?</div>Open opponent spot</div>}
        <div className="mt-8 border-t border-[#e2dccb] pt-5">{isHost ? <button type="button" onClick={onStart} disabled={starting || room.players.length < 2} className="btn-press flex w-full items-center justify-center rounded-2xl bg-[#ee604c] px-4 py-4 font-bold text-[#fffaf0] ludo-shadow-sm disabled:cursor-not-allowed disabled:opacity-45" data-testid="button-start-match">{starting ? <Loader2 className="mr-2 h-5 w-5 animate-spin" /> : <ChevronRight className="mr-2 h-5 w-5" />}{room.players.length < 2 ? 'Waiting for an opponent' : starting || room.wagerStatus === 'collecting' ? 'Collecting stakes…' : 'Start the match'}</button> : <div className="flex items-center gap-3 rounded-2xl bg-[#f0e8d4] px-4 py-4 text-sm font-medium text-[#68675e]"><Clock3 className="h-5 w-5 text-[#ee604c]" />{room.wagerStatus === 'collecting' ? 'The host is securing the stakes.' : 'The host will start when ready.'}</div>}</div>
        <div className="mt-5 flex items-center gap-2 text-[11px] font-medium leading-relaxed text-[#969082]"><Shield className="h-4 w-4 shrink-0 text-[#3a9b9b]" />Your player identity is saved only for this room.</div>
      </aside>
    </div>
  );
}

function Match({ room, playerId, me, currentPlayer, isMyTurn, selectedToken, rolling, onRoll, onSelectToken, busy }: { room: Room; playerId: string; me?: Player; currentPlayer?: Player; isMyTurn: boolean; selectedToken: string | null; rolling: boolean; onRoll: () => void; onSelectToken: (key: string, index: number) => void; busy: boolean }) {
  const winner = room.players.find((player) => player.id === room.winnerId);
  return (
    <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_350px]">
      <section><div className="mb-4 flex flex-wrap items-center justify-between gap-3"><div className={`flex items-center gap-3 rounded-2xl border-2 px-4 py-3 ${isMyTurn ? 'border-[#ee604c] bg-[#fff5ea]' : 'border-[#d9d1bd] bg-[#fffaf0]'}`} data-testid="status-turn"><div className="relative"><Avatar player={currentPlayer ?? me ?? room.players[0]} index={room.players.findIndex((player) => player.id === (currentPlayer?.id ?? me?.id))} size="sm" /></div><div><div className="text-xs font-bold uppercase tracking-[.12em] text-[#7f7b70]">{room.status === 'finished' ? 'Winner' : isMyTurn ? 'Your turn' : 'Now playing'}</div><div className="font-bold">{winner?.name ?? currentPlayer?.name ?? 'Waiting for turn'}</div></div></div><div className="flex items-center gap-2 text-xs font-bold text-[#969082]"><RotateCw className={`h-4 w-4 ${busy ? 'animate-spin' : ''}`} />Live room · updates every few seconds</div></div><LudoBoard room={room} meId={playerId} selectedToken={selectedToken} onSelectToken={onSelectToken} /></section>
      <aside className="space-y-5">
        <div className="rounded-[28px] border-[3px] border-[#202538] bg-[#fffaf0] p-5 ludo-shadow sm:p-6"><SectionLabel>Your move</SectionLabel>{room.status === 'finished' ? <div className="rounded-2xl bg-[#f6d85a] p-5"><Trophy className="h-8 w-8 text-[#202538]" /><div className="mt-3 font-display text-2xl font-bold">{winner?.id === playerId ? 'You took it.' : `${winner?.name ?? 'A friend'} wins.`}</div><div className="mt-1 text-sm text-[#68675e]">That was a good one. Run it back from the home screen.</div></div> : <><div className="flex items-center gap-5"><Dice value={room.dice} rolling={rolling} onClick={onRoll} disabled={!isMyTurn || room.dice !== null || busy} /><div><div className="font-display text-2xl font-bold leading-none">{room.dice ? `You rolled ${room.dice}` : isMyTurn ? 'Roll to begin' : 'Hang tight'}</div><div className="mt-2 text-sm leading-relaxed text-[#7f7b70]">{room.dice ? 'Choose one of your glowing tokens on the board.' : isMyTurn ? 'Make your move and pass the table.' : `${currentPlayer?.name ?? 'Your friend'} is choosing their next move.`}</div></div></div>{isMyTurn && room.dice === null && <button type="button" onClick={onRoll} disabled={busy} className="btn-press mt-5 flex w-full items-center justify-center rounded-2xl bg-[#ee604c] px-4 py-3.5 font-bold text-[#fffaf0] disabled:opacity-50" data-testid="button-roll-dice">Roll the dice</button>}{isMyTurn && room.dice !== null && <div className="mt-5 rounded-2xl border-2 border-[#3a9b9b]/40 bg-[#e7f5f1] px-4 py-3 text-sm font-bold text-[#276c6c]" data-testid="status-select-token">Pick a token on the board to move it {room.dice} spaces.</div>}</>}</div>
        <WagerCard room={room} />
        <div className="rounded-[28px] border-2 border-[#d9d1bd] bg-[#fffaf0] p-5"><SectionLabel><Users className="h-3.5 w-3.5" />Players</SectionLabel><div className="space-y-2">{room.players.map((player, index) => <PlayerRow key={player.id} player={player} index={index} isCurrent={player.id === room.currentPlayerId} isHost={player.id === room.hostId} />)}</div></div>
        <div className="rounded-2xl bg-[#f0e8d4] p-4 text-xs leading-relaxed text-[#7f7b70]"><span className="font-bold text-[#202538]">Tiny table rule:</span> roll, choose a glowing token, then pass the spotlight. Keep an eye on the turn marker.</div>
      </aside>
    </div>
  );
}

function formatRupees(value: number) {
  return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 2 }).format(value);
}

function WagerCard({ room }: { room: Room }) {
  if (room.betAmount <= 0) return null;
  const pot = room.potAmount || room.betAmount * room.players.length;
  const commission = room.commissionAmount ?? Math.round(pot * 100 * 0.05) / 100;
  const payout = room.winnerPayout ?? pot - commission;
  const statusText = room.status === 'cancelled' && room.wagerStatus === 'escrowed'
    ? 'Refunding the collected stakes…'
    : room.status === 'finished' && room.wagerStatus === 'escrowed'
      ? 'Processing the winner payout…'
      : room.wagerStatus === 'collecting'
        ? 'Collecting each player’s stake…'
        : room.wagerStatus === 'escrowed'
      ? 'Stakes secured for this match.'
      : room.wagerStatus === 'settled'
        ? 'Winner payout settled.'
        : room.wagerStatus === 'refunded'
          ? 'All collected stakes have been refunded.'
          : 'Collected from each wallet when the host starts.';
  return (
    <div className="my-4 rounded-2xl border-2 border-[#3a9b9b]/35 bg-[#e7f5f1] p-4" data-testid="card-wager-summary">
      <div className="text-[10px] font-bold uppercase tracking-[.16em] text-[#276c6c]">Wallet wager · INR</div>
      <div className="mt-2 flex items-center justify-between gap-3 text-sm"><span className="text-[#68675e]">Stake per player</span><strong>{formatRupees(room.betAmount)}</strong></div>
      <div className="mt-1 flex items-center justify-between gap-3 text-sm"><span className="text-[#68675e]">{room.status === 'waiting' ? 'Pot on start' : 'Current pot'}</span><strong>{formatRupees(pot)}</strong></div>
      <div className="mt-1 flex items-center justify-between gap-3 text-sm"><span className="text-[#68675e]">5% platform commission</span><strong>{formatRupees(commission)}</strong></div>
      <div className="mt-1 flex items-center justify-between gap-3 text-sm"><span className="text-[#68675e]">Winner receives</span><strong>{formatRupees(payout)}</strong></div>
      <div className="mt-3 border-t border-[#3a9b9b]/20 pt-3 text-xs font-semibold leading-relaxed text-[#276c6c]">{statusText}</div>
    </div>
  );
}

function CancelledRoom({ room }: { room: Room }) {
  return (
    <section className="mx-auto max-w-2xl rounded-[28px] border-[3px] border-[#202538] bg-[#fffaf0] p-6 ludo-shadow sm:p-9">
      <div className="font-display text-3xl font-bold">This match is closed.</div>
      <p className="mt-2 text-sm leading-relaxed text-[#7f7b70]">A player left before the match ended, so the game was canceled.</p>
      {room.betAmount > 0 && <WagerCard room={room} />}
      <div className="mt-4 text-sm font-medium text-[#68675e]">Return to the challenge board to create or join another match.</div>
    </section>
  );
}

function LoadingSkeleton() {
  return <div className="min-h-[100dvh] bg-[#f4efdf] p-6"><div className="mx-auto max-w-6xl animate-pulse"><div className="h-11 w-36 rounded-xl bg-[#e2dccb]" /><div className="mt-10 h-14 w-72 rounded-xl bg-[#e2dccb]" /><div className="mt-7 grid gap-6 lg:grid-cols-[1fr_350px]"><div className="h-[570px] rounded-[28px] bg-[#e2dccb]" /><div className="h-96 rounded-[28px] bg-[#e2dccb]" /></div></div></div>;
}