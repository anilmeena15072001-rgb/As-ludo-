import { getApp, getApps, initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getDatabase } from "firebase/database";

const firebaseConfig = {
  apiKey: "AIzaSyDwOl60MW9naBTbPHhINK2IZLAOPcHFeMM",
  authDomain: "ludo-zone-d7b9f.firebaseapp.com",
  databaseURL: "https://ludo-zone-d7b9f-default-rtdb.firebaseio.com",
  projectId: "ludo-zone-d7b9f",
  storageBucket: "ludo-zone-d7b9f.firebasestorage.app",
  messagingSenderId: "35328676145",
  appId: "1:35328676145:web:2d03ce3da7e3070f8c6010",
  measurementId: "G-TXWG530XG1",
};

const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);

export const firebaseAuth = getAuth(app);
export const firebaseDatabase = getDatabase(app);
export const ADMIN_PHONE_NUMBER = "+918529340849";