import { useEffect, useState } from "react";
import { onValue, push, ref, serverTimestamp, set, update } from "firebase/database";
import { ArrowDownToLine, Ban, Check, FileCheck2, Loader2, QrCode, ShieldCheck, WalletCards, X } from "lucide-react";
import { useFirebaseAuth } from "@/components/auth";
import { ADMIN_PHONE_NUMBER, firebaseDatabase } from "@/lib/firebase";

type KycStatus = "pending" | "approved" | "rejected";
type KycRecord = {
  fullName: string;
  documentId: string;
  phoneNumber?: string;
  status: KycStatus;
  submittedAt?: number;
  reviewedAt?: number;
  reviewedBy?: string;
};

type AdminKycRequest = KycRecord & { uid: string };

function formatRupees(value: number) {
  return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 2 }).format(value);
}

export function useAccountData() {
  const { user } = useFirebaseAuth();
  const [balance, setBalance] = useState(0);
  const [kyc, setKyc] = useState<KycRecord | null>(null);

  useEffect(() => {
    if (!user) {
      setBalance(0);
      setKyc(null);
      return;
    }
    const walletUnsubscribe = onValue(ref(firebaseDatabase, `wallets/${user.uid}`), (snapshot) => {
      const value = snapshot.val();
      setBalance(typeof value === "number" ? value : Number(value?.balance ?? 0));
    });
    const kycUnsubscribe = onValue(ref(firebaseDatabase, `kyc/${user.uid}`), (snapshot) => {
      setKyc(snapshot.exists() ? (snapshot.val() as KycRecord) : null);
    });
    return () => {
      walletUnsubscribe();
      kycUnsubscribe();
    };
  }, [user]);

  return { balance, kyc, isAdmin: user?.phoneNumber === ADMIN_PHONE_NUMBER };
}

export function AccountBar({ showAdminKyc = true }: { showAdminKyc?: boolean }) {
  const { user, logout } = useFirebaseAuth();
  const { balance, kyc, isAdmin } = useAccountData();
  const [panel, setPanel] = useState<"wallet" | "kyc" | "admin" | null>(null);
  if (!user) return null;

  return (
    <>
      <div className="flex flex-wrap items-center justify-end gap-2">
        <button type="button" onClick={() => setPanel("wallet")} className="flex items-center gap-2 rounded-xl border-2 border-[#d9d1bd] bg-[#fffaf0] px-3 py-2 text-xs font-bold text-[#202538]">
          <WalletCards className="h-4 w-4 text-[#3a9b9b]" /> {formatRupees(balance)}
        </button>
        <button type="button" onClick={() => setPanel("kyc")} className="flex items-center gap-2 rounded-xl border-2 border-[#d9d1bd] bg-[#fffaf0] px-3 py-2 text-xs font-bold text-[#202538]">
          <FileCheck2 className={`h-4 w-4 ${kyc?.status === "approved" ? "text-[#3a9b9b]" : "text-[#ee604c]"}`} /> KYC {kyc?.status ?? "required"}
        </button>
        {showAdminKyc && isAdmin && <button type="button" onClick={() => setPanel("admin")} className="rounded-xl bg-[#202538] px-3 py-2 text-xs font-bold text-[#fffaf0]">Admin KYC</button>}
        <button type="button" onClick={() => void logout()} className="rounded-xl px-3 py-2 text-xs font-bold text-[#7f7b70] hover:bg-[#f8e1d2] hover:text-[#ee604c]">Log out</button>
      </div>
      {panel && <AccountPanel panel={panel} onClose={() => setPanel(null)} onNavigate={setPanel} />}
    </>
  );
}

function AccountPanel({ panel, onClose, onNavigate }: { panel: "wallet" | "kyc" | "admin"; onClose: () => void; onNavigate: (panel: "wallet" | "kyc" | "admin") => void }) {
  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-[#202538]/45 p-4" role="dialog" aria-modal="true">
      <div className="max-h-[min(760px,calc(100dvh-32px))] w-full max-w-xl overflow-y-auto rounded-[28px] border-[3px] border-[#202538] bg-[#fffaf0] p-5 ludo-shadow sm:p-7">
        <div className="mb-5 flex items-start justify-between gap-4">
          <div>
            <div className="font-display text-3xl font-bold tracking-[-.05em]">{panel === "wallet" ? "Your wallet" : panel === "kyc" ? "KYC verification" : "Admin KYC queue"}</div>
            <div className="mt-1 text-sm text-[#7f7b70]">{panel === "wallet" ? "Wallet balance and withdrawal requests." : panel === "kyc" ? "Approved KYC is required before withdrawals." : "Review verification requests from players."}</div>
          </div>
          <button type="button" onClick={onClose} className="grid h-10 w-10 place-items-center rounded-xl bg-[#f0e8d4] text-[#202538]" aria-label="Close panel"><X className="h-5 w-5" /></button>
        </div>
        {panel === "wallet" && <WalletPanel onOpenKyc={() => onNavigate("kyc")} />}
        {panel === "kyc" && <KycPanel />}
        {panel === "admin" && <AdminPanel />}
      </div>
    </div>
  );
}

function WalletPanel({ onOpenKyc }: { onOpenKyc: () => void }) {
  const { user } = useFirebaseAuth();
  const { balance, kyc } = useAccountData();
  const [amount, setAmount] = useState("");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const [requests, setRequests] = useState<{ amount: number; status: string }[]>([]);
  const [showPaymentQr, setShowPaymentQr] = useState(false);

  useEffect(() => {
    if (!user) return;
    return onValue(ref(firebaseDatabase, `withdrawals/${user.uid}`), (snapshot) => {
      const value = snapshot.val() ?? {};
      setRequests(Object.values(value) as { amount: number; status: string }[]);
    });
  }, [user]);

  async function requestWithdrawal(event: React.FormEvent) {
    event.preventDefault();
    const numericAmount = Number(amount);
    setMessage("");
    if (kyc?.status !== "approved") {
      setMessage("Complete and get KYC approved before requesting a withdrawal.");
      return;
    }
    if (!Number.isFinite(numericAmount) || numericAmount <= 0 || numericAmount > balance) {
      setMessage("Enter an amount greater than zero and within your wallet balance.");
      return;
    }
    if (!user) return;
    setBusy(true);
    try {
      const requestRef = push(ref(firebaseDatabase, `withdrawals/${user.uid}`));
      await set(requestRef, { amount: numericAmount, status: "pending", createdAt: serverTimestamp(), phoneNumber: user.phoneNumber });
      setAmount("");
      setMessage("Withdrawal request submitted for admin review.");
    } catch {
      setMessage("Could not submit the withdrawal request. Try again.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-5">
      <div className="rounded-2xl border-2 border-[#3a9b9b]/35 bg-[#e7f5f1] p-5">
        <div className="text-xs font-bold uppercase tracking-[.16em] text-[#276c6c]">Available balance</div>
        <div className="mt-2 font-display text-5xl font-bold tracking-[-.06em] text-[#202538]">{formatRupees(balance)}</div>
        <div className="mt-2 text-sm text-[#276c6c]">Live from your Firebase wallet record.</div>
      </div>
      <button
        type="button"
        onClick={() => setShowPaymentQr((visible) => !visible)}
        aria-expanded={showPaymentQr}
        aria-controls="add-payment-qr"
        data-testid="button-add-payment"
        className="flex w-full items-center justify-center gap-2 rounded-xl bg-[#3a9b9b] px-4 py-3.5 font-bold text-[#fffaf0] transition-colors hover:bg-[#307f7f]"
      >
        <QrCode className="h-5 w-5" />
        {showPaymentQr ? "Hide payment QR" : "Add Payment"}
      </button>
      {showPaymentQr && (
        <section
          id="add-payment-qr"
          className="rounded-2xl border-2 border-[#3a9b9b]/35 bg-[#e7f5f1] p-5 text-center"
          data-testid="section-add-payment"
        >
          <h3 className="font-display text-2xl font-bold text-[#202538]">Scan to make a payment</h3>
          <p className="mt-1 text-sm text-[#276c6c]">Scan this QR code with your payment app.</p>
          <img
            src={`${import.meta.env.BASE_URL}add-payment-qr.jpg`}
            alt="Payment QR code"
            className="mx-auto mt-4 aspect-square w-full max-w-[280px] rounded-xl border border-[#d9d1bd] bg-white p-2 object-contain"
          />
          <p className="mx-auto mt-3 max-w-sm text-xs leading-relaxed text-[#7f7b70]">
            Scanning does not automatically update your wallet balance. Payments must be verified separately.
          </p>
        </section>
      )}
      <form onSubmit={requestWithdrawal} className="rounded-2xl border-2 border-[#d9d1bd] bg-[#fffdf6] p-4">
        <div className="mb-3 flex items-center gap-2 text-sm font-bold"><ArrowDownToLine className="h-4 w-4 text-[#ee604c]" /> Request withdrawal</div>
        <div className="flex gap-2">
          <input value={amount} onChange={(event) => setAmount(event.target.value.replace(/[^\d.]/g, ""))} placeholder="Amount in ₹" inputMode="decimal" className="min-w-0 flex-1 rounded-xl border-2 border-[#d9d1bd] bg-[#fffaf0] px-3 py-3 outline-none focus:border-[#ee604c]" />
          <button type="submit" disabled={busy} className="rounded-xl bg-[#ee604c] px-4 py-3 text-sm font-bold text-[#fffaf0] disabled:opacity-60">{busy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Request"}</button>
        </div>
        {kyc?.status !== "approved" && <div className="mt-3 text-xs font-medium text-[#b94b3c]">KYC approval is required before withdrawals.</div>}
        {message && <div className="mt-3 rounded-xl bg-[#f0e8d4] px-3 py-2 text-xs font-bold text-[#68675e]">{message}</div>}
      </form>
      {requests.length > 0 && <div><div className="mb-2 text-xs font-bold uppercase tracking-[.16em] text-[#7f7b70]">Recent requests</div><div className="space-y-2">{requests.slice(-4).reverse().map((request, index) => <div key={`${request.amount}-${index}`} className="flex items-center justify-between rounded-xl border border-[#e2dccb] px-3 py-3 text-sm"><span>{formatRupees(Number(request.amount))}</span><span className="font-bold capitalize text-[#7f7b70]">{request.status}</span></div>)}</div></div>}
      <div className="flex items-start gap-2 text-xs leading-relaxed text-[#7f7b70]"><ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-[#3a9b9b]" />Your phone number is used as the Firebase account identity for wallet and KYC records.</div>
      <button type="button" onClick={onOpenKyc} className="text-sm font-bold text-[#ee604c]">Open KYC verification</button>
    </div>
  );
}

function KycPanel() {
  const { user } = useFirebaseAuth();
  const { kyc } = useAccountData();
  const [fullName, setFullName] = useState(kyc?.fullName ?? "");
  const [documentId, setDocumentId] = useState(kyc?.documentId ?? "");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    setFullName(kyc?.fullName ?? "");
    setDocumentId(kyc?.documentId ?? "");
  }, [kyc]);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    if (!user || fullName.trim().length < 2 || documentId.trim().length < 4) {
      setMessage("Enter your full name and a valid ID number.");
      return;
    }
    setBusy(true);
    setMessage("");
    try {
      await update(ref(firebaseDatabase, `kyc/${user.uid}`), {
        fullName: fullName.trim(),
        documentId: documentId.trim(),
        phoneNumber: user.phoneNumber,
        status: "pending",
        submittedAt: serverTimestamp(),
      });
      setMessage("KYC submitted. An admin will review it shortly.");
    } catch {
      setMessage("KYC could not be submitted. Check your Firebase Database Rules.");
    } finally {
      setBusy(false);
    }
  }

  const statusCopy = kyc?.status === "approved" ? "Approved — withdrawals are enabled." : kyc?.status === "rejected" ? "Rejected — update your details and submit again." : kyc?.status === "pending" ? "Pending admin review." : "Not submitted yet.";
  return (
    <div className="space-y-5">
      <div className={`rounded-2xl p-4 text-sm font-bold ${kyc?.status === "approved" ? "bg-[#e7f5f1] text-[#276c6c]" : kyc?.status === "rejected" ? "bg-[#fff0e7] text-[#b94b3c]" : "bg-[#f0e8d4] text-[#68675e]"}`}>{statusCopy}</div>
      <form onSubmit={submit} className="space-y-4">
        <label className="block"><span className="mb-2 block text-xs font-bold uppercase tracking-[.16em] text-[#7f7b70]">Full name</span><input value={fullName} onChange={(event) => setFullName(event.target.value)} placeholder="As shown on your ID" className="w-full rounded-xl border-2 border-[#d9d1bd] bg-[#fffdf6] px-3 py-3 outline-none focus:border-[#ee604c]" /></label>
        <label className="block"><span className="mb-2 block text-xs font-bold uppercase tracking-[.16em] text-[#7f7b70]">Government ID</span><input value={documentId} onChange={(event) => setDocumentId(event.target.value)} placeholder="ID number" className="w-full rounded-xl border-2 border-[#d9d1bd] bg-[#fffdf6] px-3 py-3 outline-none focus:border-[#ee604c]" /></label>
        <button type="submit" disabled={busy || kyc?.status === "pending"} className="flex w-full items-center justify-center rounded-xl bg-[#202538] px-4 py-3.5 font-bold text-[#fffaf0] disabled:opacity-50">{busy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <FileCheck2 className="mr-2 h-4 w-4" />}{kyc?.status === "pending" ? "Waiting for review" : "Submit KYC"}</button>
      </form>
      {message && <div className="rounded-xl bg-[#e7f5f1] px-3 py-2 text-xs font-bold text-[#276c6c]">{message}</div>}
      <div className="flex items-start gap-2 text-xs leading-relaxed text-[#7f7b70]"><ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-[#3a9b9b]" />Only your authenticated Firebase account and the authorized admin can access this record.</div>
    </div>
  );
}

function AdminPanel() {
  const { user } = useFirebaseAuth();
  const [requests, setRequests] = useState<AdminKycRequest[]>([]);
  const [busyUid, setBusyUid] = useState("");
  const isAdmin = user?.phoneNumber === ADMIN_PHONE_NUMBER;

  useEffect(() => {
    if (!isAdmin) return;
    return onValue(ref(firebaseDatabase, "kyc"), (snapshot) => {
      const value = snapshot.val() ?? {};
      setRequests(Object.entries(value).map(([uid, record]) => ({ uid, ...(record as KycRecord) })));
    });
  }, [isAdmin]);

  async function review(uid: string, status: "approved" | "rejected") {
    if (!isAdmin) return;
    setBusyUid(uid);
    try {
      await update(ref(firebaseDatabase, `kyc/${uid}`), { status, reviewedAt: serverTimestamp(), reviewedBy: user.phoneNumber });
    } finally {
      setBusyUid("");
    }
  }

  if (!isAdmin) return <div className="rounded-2xl bg-[#fff0e7] p-4 text-sm font-bold text-[#b94b3c]">Admin access is restricted.</div>;
  const pending = requests.filter((request) => request.status === "pending");
  return (
    <div className="space-y-3">
      {pending.length === 0 ? <div className="rounded-2xl border-2 border-dashed border-[#d9d1bd] p-7 text-center text-sm font-medium text-[#7f7b70]">No pending KYC requests.</div> : pending.map((request) => <div key={request.uid} className="rounded-2xl border-2 border-[#d9d1bd] bg-[#fffdf6] p-4"><div className="flex items-start justify-between gap-3"><div><div className="font-bold">{request.fullName}</div><div className="mt-1 text-xs text-[#7f7b70]">{request.phoneNumber ?? "Phone hidden"} · ID: {request.documentId}</div></div><span className="rounded-full bg-[#f6d85a] px-2 py-1 text-[10px] font-bold uppercase tracking-[.1em]">Pending</span></div><div className="mt-4 flex gap-2"><button type="button" disabled={busyUid === request.uid} onClick={() => void review(request.uid, "approved")} className="flex flex-1 items-center justify-center rounded-xl bg-[#3a9b9b] px-3 py-2.5 text-sm font-bold text-[#fffaf0]"><Check className="mr-1.5 h-4 w-4" /> Approve</button><button type="button" disabled={busyUid === request.uid} onClick={() => void review(request.uid, "rejected")} className="flex flex-1 items-center justify-center rounded-xl bg-[#fff0e7] px-3 py-2.5 text-sm font-bold text-[#b94b3c]"><Ban className="mr-1.5 h-4 w-4" /> Reject</button></div></div>)}
    </div>
  );
}