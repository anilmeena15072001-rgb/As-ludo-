import { Crown, Dice5, LogOut, RefreshCw, Sparkles, Users, X } from 'lucide-react';
import type { CSSProperties, ReactNode } from 'react';
import type { Player, Room } from '@workspace/api-client-react';

export const palette = ['#ee604c', '#3a9b9b', '#a990c5', '#e2ad36'];

export function LogoMark({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex items-center gap-3" data-testid="brand-room-ludo">
      <div className="grid h-11 w-11 shrink-0 rotate-[-7deg] place-items-center rounded-[14px] border-[3px] border-[#202538] bg-[#f6d85a] ludo-shadow-sm">
        <div className="grid grid-cols-2 gap-1">
          <span className="h-2 w-2 rounded-full bg-[#ee604c]" />
          <span className="h-2 w-2 rounded-full bg-[#3a9b9b]" />
          <span className="h-2 w-2 rounded-full bg-[#a990c5]" />
          <span className="h-2 w-2 rounded-full bg-[#202538]" />
        </div>
      </div>
      {!compact && (
        <div>
          <div className="font-display text-xl font-bold leading-none tracking-[-.04em] text-[#202538]">Room Ludo</div>
          <div className="mt-1 text-[10px] font-bold uppercase tracking-[.2em] text-[#ee604c]">game night, together</div>
        </div>
      )}
    </div>
  );
}

export function colorForPlayer(color: string, index = 0) {
  const value = color?.toLowerCase() ?? '';
  if (value.includes('red') || value.includes('coral')) return '#ee604c';
  if (value.includes('blue') || value.includes('teal') || value.includes('green')) return '#3a9b9b';
  if (value.includes('purple') || value.includes('violet')) return '#a990c5';
  if (value.includes('yellow') || value.includes('gold')) return '#e2ad36';
  return palette[index % palette.length];
}

export function Avatar({ player, index = 0, size = 'md' }: { player: Player; index?: number; size?: 'sm' | 'md' }) {
  const color = colorForPlayer(player.color, index);
  return (
    <div
      className={`${size === 'sm' ? 'h-8 w-8 text-xs' : 'h-10 w-10 text-sm'} grid shrink-0 place-items-center rounded-full border-2 border-[#202538] font-bold text-[#202538]`}
      style={{ backgroundColor: color }}
      data-testid={`avatar-player-${player.id}`}
      title={player.name}
    >
      {player.name.slice(0, 2).toUpperCase()}
    </div>
  );
}

export function PlayerRow({ player, index, isCurrent, isHost }: { player: Player; index: number; isCurrent: boolean; isHost: boolean }) {
  return (
    <div className={`flex items-center gap-3 rounded-2xl border px-3 py-3 transition-colors ${isCurrent ? 'border-[#ee604c] bg-[#fff5ea]' : 'border-[#e2dccb] bg-[#fffaf0]'}`} data-testid={`row-player-${player.id}`}>
      <Avatar player={player} index={index} size="sm" />
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-1.5 truncate text-sm font-bold text-[#202538]">
          <span data-testid={`text-player-name-${player.id}`}>{player.name}</span>
          {isHost && <Crown className="h-3.5 w-3.5 text-[#e2ad36]" fill="currentColor" />}
        </div>
        <div className="mt-0.5 text-[11px] font-medium text-[#7f7b70]">{isCurrent ? 'Their turn' : isHost ? 'Room host' : 'Ready to play'}</div>
      </div>
      <span className={`h-2.5 w-2.5 rounded-full ${isCurrent ? 'status-pulse bg-[#ee604c]' : 'bg-[#b9b2a0]'}`} />
    </div>
  );
}

export function Dice({ value, rolling, onClick, disabled }: { value: number | null; rolling: boolean; onClick?: () => void; disabled?: boolean }) {
  const face = value ?? 0;
  const pipPositions: Record<number, string[]> = {
    1: ['center'], 2: ['top-left', 'bottom-right'], 3: ['top-left', 'center', 'bottom-right'],
    4: ['top-left', 'top-right', 'bottom-left', 'bottom-right'], 5: ['top-left', 'top-right', 'center', 'bottom-left', 'bottom-right'],
    6: ['top-left', 'top-right', 'middle-left', 'middle-right', 'bottom-left', 'bottom-right'],
  };
  const pipClass: Record<string, string> = {
    center: 'left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2', 'top-left': 'left-[19%] top-[19%]', 'top-right': 'right-[19%] top-[19%]',
    'middle-left': 'left-[19%] top-1/2 -translate-y-1/2', 'middle-right': 'right-[19%] top-1/2 -translate-y-1/2',
    'bottom-left': 'bottom-[19%] left-[19%]', 'bottom-right': 'bottom-[19%] right-[19%]',
  };
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className={`relative h-24 w-24 rounded-[22px] border-[3px] border-[#202538] bg-[#fffaf0] ludo-shadow-sm transition-transform ${rolling ? 'roll-pop' : ''} ${onClick && !disabled ? 'btn-press' : ''}`}
      data-testid="button-dice"
      aria-label={value ? `Dice shows ${value}` : 'Roll the dice'}
    >
      {face ? pipPositions[face]?.map((position) => <span key={position} className={`absolute h-3.5 w-3.5 rounded-full bg-[#ee604c] ${pipClass[position]}`} />) : <Dice5 className="absolute inset-0 m-auto h-10 w-10 text-[#202538]" />}
    </button>
  );
}

const pathCells = [
  [5, 0], [6, 0], [7, 0], [8, 0], [9, 0], [10, 0], [10, 1], [10, 2], [10, 3], [10, 4], [10, 5],
  [10, 6], [10, 7], [10, 8], [10, 9], [10, 10], [9, 10], [8, 10], [7, 10], [6, 10], [5, 10],
  [4, 10], [3, 10], [2, 10], [1, 10], [0, 10], [0, 9], [0, 8], [0, 7], [0, 6], [0, 5],
  [0, 4], [0, 3], [0, 2], [0, 1], [0, 0], [1, 0], [2, 0], [3, 0], [4, 0],
];

function tokenCss(player: Player, index: number, x: number, y: number): CSSProperties {
  const color = colorForPlayer(player.color, index);
  return { left: `${(x / 11) * 100}%`, top: `${(y / 11) * 100}%`, backgroundColor: color, borderColor: '#fffaf0' };
}

export function LudoBoard({ room, meId, selectedToken, onSelectToken }: { room: Room; meId: string; selectedToken: string | null; onSelectToken: (key: string, index: number) => void }) {
  const canChoose = room.status === 'playing' && room.currentPlayerId === meId && room.dice !== null;
  return (
    <div className="rounded-[28px] border-[3px] border-[#202538] bg-[#202538] p-3 ludo-shadow" data-testid="board-ludo">
      <div className="board-grid overflow-hidden rounded-[19px] bg-[#f6d85a] p-2">
        {Array.from({ length: 121 }).map((_, i) => {
          const x = i % 11;
          const y = Math.floor(i / 11);
          const path = pathCells.some(([px, py]) => px === x && py === y);
          return <div className={`board-cell ${path ? 'path' : ''} ${path && i % 5 === 0 ? 'safe' : ''}`} key={`${x}-${y}`} />;
        })}
        <div className="board-home left-[2%] top-[2%] bg-[#ee604c]" style={{ '--home': '#ee604c' } as CSSProperties}>
          <div className="board-home-inner bg-[#fff1e8]">
            {room.players[0]?.tokens.map((position, tokenIndex) => position <= 0 && <TokenButton key={`home-0-${tokenIndex}`} player={room.players[0]} playerIndex={0} tokenIndex={tokenIndex} canChoose={canChoose && room.players[0].id === meId} selected={selectedToken === `${room.players[0].id}-${tokenIndex}`} onSelect={onSelectToken} />)}
          </div>
        </div>
        <div className="board-home right-[2%] top-[2%] bg-[#3a9b9b]">
          <div className="board-home-inner bg-[#e7f5f1]">
            {room.players[1]?.tokens.map((position, tokenIndex) => position <= 0 && <TokenButton key={`home-1-${tokenIndex}`} player={room.players[1]} playerIndex={1} tokenIndex={tokenIndex} canChoose={canChoose && room.players[1].id === meId} selected={selectedToken === `${room.players[1].id}-${tokenIndex}`} onSelect={onSelectToken} />)}
          </div>
        </div>
        <div className="board-home bottom-[2%] left-[2%] bg-[#a990c5]">
          <div className="board-home-inner bg-[#f1eafa]">
            {room.players[2]?.tokens.map((position, tokenIndex) => position <= 0 && <TokenButton key={`home-2-${tokenIndex}`} player={room.players[2]} playerIndex={2} tokenIndex={tokenIndex} canChoose={canChoose && room.players[2].id === meId} selected={selectedToken === `${room.players[2].id}-${tokenIndex}`} onSelect={onSelectToken} />)}
          </div>
        </div>
        <div className="board-home bottom-[2%] right-[2%] bg-[#e2ad36]">
          <div className="board-home-inner bg-[#fff7db]">
            {room.players[3]?.tokens.map((position, tokenIndex) => position <= 0 && <TokenButton key={`home-3-${tokenIndex}`} player={room.players[3]} playerIndex={3} tokenIndex={tokenIndex} canChoose={canChoose && room.players[3].id === meId} selected={selectedToken === `${room.players[3].id}-${tokenIndex}`} onSelect={onSelectToken} />)}
          </div>
        </div>
        <div className="absolute left-[36.5%] top-[36.5%] grid h-[27%] w-[27%] place-items-center rounded-[18px] border-[3px] border-[#202538] bg-[#fffaf0]">
          <div className="text-center">
            <Sparkles className="mx-auto h-7 w-7 text-[#ee604c]" />
            <div className="mt-1 text-[9px] font-bold uppercase tracking-[.18em] text-[#202538]">race home</div>
          </div>
        </div>
        {room.players.map((player, playerIndex) => player.tokens.map((position, tokenIndex) => {
          if (position <= 0) return null;
          const [x, y] = pathCells[(position - 1 + playerIndex * 4) % pathCells.length];
          const key = `${player.id}-${tokenIndex}`;
          return (
            <button
              key={key}
              type="button"
              className={`board-token absolute z-10 -translate-x-1/2 -translate-y-1/2 ${canChoose && player.id === meId ? 'token-ready' : ''} ${selectedToken === key ? 'selected' : ''}`}
              style={tokenCss(player, playerIndex, x + (tokenIndex % 2 ? .25 : -.25), y + (tokenIndex > 1 ? .25 : -.25))}
              onClick={() => canChoose && player.id === meId && onSelectToken(key, tokenIndex)}
              disabled={!canChoose || player.id !== meId}
              data-testid={`button-token-${player.id}-${tokenIndex}`}
              aria-label={`Choose ${player.name}'s token ${tokenIndex + 1}`}
            />
          );
        }))}
      </div>
      <div className="flex items-center justify-between px-2 pt-3 text-[10px] font-bold uppercase tracking-[.16em] text-[#f4efdf]/70">
        <span>Tokens race around the track</span><span>First all four home wins</span>
      </div>
    </div>
  );
}

function TokenButton({ player, playerIndex, tokenIndex, canChoose, selected, onSelect }: { player: Player; playerIndex: number; tokenIndex: number; canChoose: boolean; selected: boolean; onSelect: (key: string, index: number) => void }) {
  const key = `${player.id}-${tokenIndex}`;
  return <button type="button" className={`board-token ${canChoose ? 'token-ready' : ''} ${selected ? 'selected' : ''}`} style={{ backgroundColor: colorForPlayer(player.color, playerIndex) }} disabled={!canChoose} onClick={() => onSelect(key, tokenIndex)} data-testid={`button-home-token-${player.id}-${tokenIndex}`} aria-label={`Choose token ${tokenIndex + 1}`} />;
}

export function SectionLabel({ children }: { children: ReactNode }) {
  return <div className="mb-3 flex items-center gap-2 text-[11px] font-bold uppercase tracking-[.2em] text-[#7f7b70]"><span className="h-2 w-2 rounded-full bg-[#ee604c]" />{children}</div>;
}

export function LoadingRoom() {
  return <div className="min-h-[100dvh] bg-[#f4efdf] p-6"><div className="mx-auto max-w-6xl animate-pulse"><div className="h-10 w-40 rounded-xl bg-[#e2dccb]" /><div className="mt-12 grid gap-6 md:grid-cols-[1fr_320px]"><div className="h-[520px] rounded-[28px] bg-[#e2dccb]" /><div className="h-80 rounded-[28px] bg-[#e2dccb]" /></div></div></div>;
}

export function ErrorNotice({
  message,
  onRetry,
  onBack,
}: {
  message: string;
  onRetry: () => void;
  onBack?: () => void;
}) {
  return (
    <main className="game-noise grid min-h-[100dvh] place-items-center p-5 text-[#202538]">
      <section className="w-full max-w-xl rounded-2xl border-2 border-[#ee604c] bg-[#fff5ea] p-5" data-testid="status-room-error">
        <div className="font-bold">That match is unavailable.</div>
        <div className="mt-1 text-sm text-[#7f7b70]">{message}</div>
        <div className="mt-4 flex flex-wrap gap-3">
          <button type="button" onClick={onRetry} className="rounded-xl bg-[#ee604c] px-4 py-2 text-sm font-bold text-[#fffaf0] btn-press" data-testid="button-retry-room">
            <RefreshCw className="mr-2 inline h-4 w-4" />Try again
          </button>
          {onBack && (
            <button type="button" onClick={onBack} className="rounded-xl border-2 border-[#d9d1bd] bg-[#fffaf0] px-4 py-2 text-sm font-bold text-[#202538]" data-testid="button-browse-challenges">
              Browse open challenges
            </button>
          )}
        </div>
      </section>
    </main>
  );
}

export function LeaveButton({ onClick, pending }: { onClick: () => void; pending: boolean }) {
  return <button type="button" onClick={onClick} disabled={pending} className="rounded-xl px-3 py-2 text-xs font-bold text-[#7f7b70] transition-colors hover:bg-[#f8e1d2] hover:text-[#ee604c] disabled:opacity-60" data-testid="button-leave-room"><LogOut className="mr-1.5 inline h-3.5 w-3.5" />{pending ? 'Leaving…' : 'Leave match'}</button>;
}