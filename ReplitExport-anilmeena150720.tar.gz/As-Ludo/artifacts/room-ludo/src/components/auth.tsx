import {
  ConfirmationResult,
  RecaptchaVerifier,
  onAuthStateChanged,
  signInWithPhoneNumber,
  signOut,
  type User,
} from "firebase/auth";
import { createContext, useContext, useEffect, useRef, useState } from "react";
import { firebaseAuth } from "@/lib/firebase";
import { Loader2, LogOut, Phone, ShieldCheck } from "lucide-react";
import { setAuthTokenGetter } from "@workspace/api-client-react";

type AuthContextValue = {
  user: User | null;
  loading: boolean;
  logout: () => Promise<void>;
};

type FirebaseAuthError = {
  code: string;
  message: string;
};

const AuthContext = createContext<AuthContextValue | null>(null);

function getFirebaseAuthError(error: unknown): FirebaseAuthError {
  if (typeof error === "object" && error !== null) {
    const candidate = error as { code?: unknown; message?: unknown };
    return {
      code: typeof candidate.code === "string" ? candidate.code : "unknown",
      message: typeof candidate.message === "string" ? candidate.message : String(error),
    };
  }
  return { code: "unknown", message: String(error) };
}

export function FirebaseAuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setAuthTokenGetter(async () => firebaseAuth.currentUser?.getIdToken() ?? null);
    const unsubscribe = onAuthStateChanged(firebaseAuth, (nextUser) => {
      setUser(nextUser);
      setLoading(false);
    });
    return () => {
      unsubscribe();
      setAuthTokenGetter(null);
    };
  }, []);

  return (
    <AuthContext.Provider value={{ user, loading, logout: () => signOut(firebaseAuth) }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useFirebaseAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error("useFirebaseAuth must be used inside FirebaseAuthProvider");
  return context;
}

export function PhoneLogin({ compact = false }: { compact?: boolean }) {
  const [phone, setPhone] = useState("");
  const [otp, setOtp] = useState("");
  const [confirmation, setConfirmation] = useState<ConfirmationResult | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<FirebaseAuthError | null>(null);
  const recaptcha = useRef<RecaptchaVerifier | null>(null);
  const recaptchaContainer = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    return () => {
      recaptcha.current?.clear();
      recaptcha.current = null;
    };
  }, []);

  async function requestOtp(event: React.FormEvent) {
    event.preventDefault();
    const normalizedPhone = phone.trim().replace(/[\s()-]/g, "");
    if (!/^\+[1-9]\d{7,14}$/.test(normalizedPhone)) {
      setError({
        code: "client/invalid-phone-format",
        message: "Use international format, for example +919876543210.",
      });
      return;
    }
    setBusy(true);
    setError(null);
    try {
      if (!recaptcha.current) {
        if (!recaptchaContainer.current) {
          throw new Error("The reCAPTCHA container is not mounted yet.");
        }
        recaptcha.current = new RecaptchaVerifier(firebaseAuth, recaptchaContainer.current, {
          size: "invisible",
          callback: () => {
            console.info("[Firebase Auth] Invisible reCAPTCHA completed.");
          },
          "expired-callback": () => {
            console.warn("[Firebase Auth] Invisible reCAPTCHA expired.");
          },
        });
        await recaptcha.current.render();
      }
      const result = await signInWithPhoneNumber(firebaseAuth, normalizedPhone, recaptcha.current);
      setConfirmation(result);
    } catch (caughtError) {
      const firebaseError = getFirebaseAuthError(caughtError);
      console.error("[Firebase Auth] Phone OTP request failed", caughtError);
      setError(firebaseError);
      recaptcha.current?.clear();
      recaptcha.current = null;
    } finally {
      setBusy(false);
    }
  }

  async function verifyOtp(event: React.FormEvent) {
    event.preventDefault();
    if (!confirmation || otp.trim().length < 6) {
      setError({ code: "client/invalid-otp", message: "Enter the 6-digit OTP." });
      return;
    }
    setBusy(true);
    setError(null);
    try {
      await confirmation.confirm(otp.trim());
    } catch (caughtError) {
      const firebaseError = getFirebaseAuthError(caughtError);
      console.error("[Firebase Auth] OTP verification failed", caughtError);
      setError(firebaseError);
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className={`game-noise min-h-[100dvh] text-[#202538] ${compact ? "flex items-center justify-center p-5" : ""}`}>
      <div className="mx-auto flex min-h-[100dvh] max-w-2xl items-center justify-center px-5 py-12">
        <section className="w-full rounded-[30px] border-[3px] border-[#202538] bg-[#fffaf0] p-6 ludo-shadow sm:p-9">
          <div className="mb-7 flex items-center gap-3">
            <div className="grid h-12 w-12 place-items-center rounded-2xl border-[3px] border-[#202538] bg-[#f6d85a] ludo-shadow-sm">
              <Phone className="h-5 w-5" />
            </div>
            <div>
              <div className="font-display text-2xl font-bold tracking-[-.04em]">Verify your number</div>
              <div className="mt-1 text-sm text-[#7f7b70]">Phone OTP is required before you enter a Ludo room.</div>
            </div>
          </div>
          {!confirmation ? (
            <form onSubmit={requestOtp} className="space-y-4">
              <label className="block">
                <span className="mb-2 block text-xs font-bold uppercase tracking-[.16em] text-[#7f7b70]">Phone number</span>
                <input value={phone} onChange={(event) => setPhone(event.target.value)} placeholder="+91 98765 43210" inputMode="tel" className="w-full rounded-2xl border-2 border-[#d9d1bd] bg-[#fffdf6] px-4 py-4 text-lg font-medium outline-none focus:border-[#ee604c]" />
              </label>
              <button type="submit" disabled={busy} className="btn-press flex w-full items-center justify-center rounded-2xl bg-[#ee604c] px-5 py-4 font-bold text-[#fffaf0] ludo-shadow-sm disabled:opacity-60">
                {busy ? <Loader2 className="mr-2 h-5 w-5 animate-spin" /> : <ShieldCheck className="mr-2 h-5 w-5" />}
                Send OTP
              </button>
            </form>
          ) : (
            <form onSubmit={verifyOtp} className="space-y-4">
              <div className="rounded-2xl bg-[#e7f5f1] px-4 py-3 text-sm font-medium text-[#276c6c]">OTP sent to {phone}. It may take a few seconds to arrive.</div>
              <label className="block">
                <span className="mb-2 block text-xs font-bold uppercase tracking-[.16em] text-[#7f7b70]">6-digit OTP</span>
                <input value={otp} onChange={(event) => setOtp(event.target.value.replace(/\D/g, "").slice(0, 6))} placeholder="000000" inputMode="numeric" className="w-full rounded-2xl border-2 border-[#d9d1bd] bg-[#fffdf6] px-4 py-4 text-center font-mono text-2xl font-bold tracking-[.3em] outline-none focus:border-[#ee604c]" />
              </label>
              <button type="submit" disabled={busy} className="btn-press flex w-full items-center justify-center rounded-2xl bg-[#ee604c] px-5 py-4 font-bold text-[#fffaf0] ludo-shadow-sm disabled:opacity-60">
                {busy ? <Loader2 className="mr-2 h-5 w-5 animate-spin" /> : <ShieldCheck className="mr-2 h-5 w-5" />}
                Verify & continue
              </button>
              <button type="button" onClick={() => { setConfirmation(null); setOtp(""); setError(null); recaptcha.current?.clear(); recaptcha.current = null; }} className="w-full py-2 text-sm font-bold text-[#7f7b70]">Use a different number</button>
            </form>
          )}
          {error && (
            <div className="mt-4 rounded-xl border border-[#ee604c]/40 bg-[#fff0e7] px-3 py-3 text-sm text-[#b94b3c]" role="alert">
              <div className="font-bold">Firebase error code: <code>{error.code}</code></div>
              <div className="mt-1 break-words font-mono text-xs">Firebase errorMessage: {error.message}</div>
            </div>
          )}
          <div ref={recaptchaContainer} aria-hidden="true" />
          <div className="mt-4 text-xs leading-relaxed text-[#7f7b70]">
            Firebase test numbers must be added under Authentication → Sign-in method → Phone numbers. Use the exact configured test code; test numbers do not receive SMS.
          </div>
        </section>
      </div>
    </main>
  );
}

export function UserMenu() {
  const { user, logout } = useFirebaseAuth();
  if (!user) return null;
  return (
    <button type="button" onClick={() => void logout()} className="rounded-xl px-3 py-2 text-xs font-bold text-[#7f7b70] transition-colors hover:bg-[#f8e1d2] hover:text-[#ee604c]">
      <LogOut className="mr-1.5 inline h-3.5 w-3.5" /> Log out
    </button>
  );
}