// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyDwOl60MW9naBTbPHhINK2IZLAOPcHFeMM",
  authDomain: "ludo-zone-d7b9f.firebaseapp.com",
  databaseURL: "https://ludo-zone-d7b9f-default-rtdb.firebaseio.com",
  projectId: "ludo-zone-d7b9f",
  storageBucket: "ludo-zone-d7b9f.firebasestorage.app",
  messagingSenderId: "35328676145",
  appId: "1:35328676145:web:2d03ce3da7e3070f8c6010",
  measurementId: "G-TXWG530XG1"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);