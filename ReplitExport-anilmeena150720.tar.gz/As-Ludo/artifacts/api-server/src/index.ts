import app from "./app";
import { logger } from "./lib/logger";
import { cleanupAbandonedWagers } from "./routes/rooms";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

void cleanupAbandonedWagers().catch((error) => {
  logger.error({ err: error }, "Initial wager recovery failed; periodic recovery will retry");
});

const wagerRecoveryInterval = setInterval(() => {
  void cleanupAbandonedWagers().catch((error) => {
    logger.error({ err: error }, "Periodic wager recovery failed");
  });
}, 5 * 60 * 1000);
wagerRecoveryInterval.unref();

app.listen(port, (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");
});
