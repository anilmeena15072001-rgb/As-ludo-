import type { Request, RequestHandler } from "express";
import { firebaseAdminAuth } from "../lib/firebase-admin";

export type AuthenticatedRequest = Request & { firebaseUid: string };

export function getFirebaseUid(req: Request): string {
  return (req as AuthenticatedRequest).firebaseUid;
}

export const requireFirebaseAuth: RequestHandler = async (req, res, next) => {
  const authorization = req.header("authorization");
  const match = authorization?.match(/^Bearer\s+(.+)$/i);

  if (!match) {
    res.status(401).json({ error: "Sign in before using a room." });
    return;
  }

  try {
    const decodedToken = await firebaseAdminAuth.verifyIdToken(match[1]);
    (req as AuthenticatedRequest).firebaseUid = decodedToken.uid;
    next();
  } catch {
    res.status(401).json({ error: "Your sign-in has expired. Sign in again." });
  }
};