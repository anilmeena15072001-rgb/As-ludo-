import { randomBytes, randomUUID } from "node:crypto";
import { Router, type IRouter, type Response } from "express";
import {
  CreateChallengeBody,
  CreateChallengeResponse,
  DeleteRoomBody,
  DeleteRoomParams,
  GetChallengesResponse,
  GetRoomParams,
  GetRoomResponse,
  JoinChallengeBody,
  JoinChallengeParams,
  JoinChallengeResponse,
  MoveTokenBody,
  MoveTokenParams,
  MoveTokenResponse,
  RollDiceBody,
  RollDiceParams,
  RollDiceResponse,
  StartRoomBody,
  StartRoomParams,
  StartRoomResponse,
} from "@workspace/api-zod";
import { getFirebaseUid, requireFirebaseAuth } from "../middleware/firebase-auth";
import { firebaseAdminDatabase } from "../lib/firebase-admin";
import {
  calculateWagerAmounts,
  collectWager,
  refundWager,
  settleWager,
  toPaise,
  WagerError,
  type WagerResult,
} from "../lib/wagers";
import { logger } from "../lib/logger";

type PlayerColor = "coral" | "teal" | "gold" | "violet";
type RoomStatus = "waiting" | "playing" | "finished" | "cancelled";
type WagerStatus = "none" | "open" | "collecting" | "escrowed" | "settled" | "refunded";

type Player = {
  id: string;
  uid: string;
  name: string;
  color: PlayerColor;
  tokens: number[];
};

type Room = {
  code: string;
  hostId: string;
  status: RoomStatus;
  currentPlayerId: string | null;
  dice: number | null;
  winnerId: string | null;
  players: Player[];
  betAmount: number;
  wagerStatus: WagerStatus;
  potAmount: number;
  commissionAmount: number | null;
  winnerPayout: number | null;
  createdAt?: number;
  lastActivityAt?: number;
};

type RoomFailure = { status: number; message: string };
type RoomUpdate = (room: Room) => RoomFailure | null;

const router: IRouter = Router();
const colors: PlayerColor[] = ["coral", "teal", "gold", "violet"];
const wagerInactivityLimitMs = 24 * 60 * 60 * 1000;

function makeId(prefix: string): string {
  return `${prefix}_${randomUUID()}`;
}

async function makeCode(): Promise<string> {
  for (let attempt = 0; attempt < 10; attempt += 1) {
    const code = randomBytes(3).toString("hex").toUpperCase();
    const existing = await firebaseAdminDatabase.ref("gameRooms").child(code).get();
    if (!existing.exists()) return code;
  }
  throw new Error("Could not allocate a unique room code.");
}

function roomRef(code: string) {
  return firebaseAdminDatabase.ref("gameRooms").child(code.toUpperCase());
}

function publicRoom(room: Room, uid: string) {
  return {
    code: room.code,
    hostId: room.hostId,
    status: room.status,
    currentPlayerId: room.currentPlayerId,
    dice: room.dice,
    winnerId: room.winnerId,
    youPlayerId: room.players.find((player) => player.uid === uid)?.id ?? null,
    betAmount: room.betAmount,
    wagerStatus: room.wagerStatus,
    potAmount: room.potAmount,
    commissionAmount: room.commissionAmount,
    winnerPayout: room.winnerPayout,
    players: room.players.map((player) => ({
      id: player.id,
      name: player.name,
      color: player.color,
      tokens: [...player.tokens],
    })),
  };
}

async function transactRoom(
  code: string,
  update: RoomUpdate,
): Promise<{ room: Room | null; failure: RoomFailure | null }> {
  let failure: RoomFailure | null = null;
  const result = await roomRef(code).transaction(
    (current) => {
      failure = null;
      if (!current || typeof current !== "object") {
        failure = { status: 404, message: "Room not found" };
        return;
      }
      const room = current as Room;
      failure = update(room);
      if (failure) return;
      return room;
    },
    undefined,
    false,
  );

  if (!result.committed) {
    return {
      room: null,
      failure: failure ?? {
        status: 503,
        message: "The room changed before this action completed. Refresh and try again.",
      },
    };
  }

  return { room: result.snapshot.val() as Room, failure: null };
}

function sendFailure(res: Response, failure: RoomFailure | null): void {
  if (!failure) {
    res.status(500).json({ error: "The room action could not be completed." });
    return;
  }
  res.status(failure.status).json({ error: failure.message });
}

function sendUnexpectedError(res: Response, error: unknown): void {
  if (error instanceof WagerError) {
    res.status(error.status).json({ error: error.message });
    return;
  }
  logger.error({ err: error }, "Room or wager operation failed");
  res.status(500).json({
    error: "The room action could not be completed. Refresh and check the room before retrying.",
  });
}

async function markWagerResult(
  code: string,
  status: "settled" | "refunded",
  result?: WagerResult,
): Promise<void> {
  const { failure } = await transactRoom(code, (room) => {
    if (room.wagerStatus === status) return null;
    if (room.wagerStatus !== "escrowed") {
      return { status: 409, message: "The room wager is not in escrow." };
    }
    room.wagerStatus = status;
    if (result) {
      room.potAmount = result.potAmount;
      room.commissionAmount = result.commissionAmount;
      room.winnerPayout = result.winnerPayout;
    }
    return null;
  });
  if (failure) throw new WagerError(failure.message, failure.status);
}

async function reconcileRoomWager(room: Room): Promise<Room> {
  if (room.status === "finished" && room.wagerStatus === "escrowed" && room.winnerId) {
    const result = await settleWager(room.code, room.winnerId);
    await markWagerResult(room.code, "settled", result);
  } else if (room.status === "cancelled" && room.wagerStatus === "escrowed") {
    await refundWager(room.code);
    await markWagerResult(room.code, "refunded");
  }

  const latest = await roomRef(room.code).get();
  if (!latest.exists()) throw new WagerError("Room not found.", 404);
  return latest.val() as Room;
}

async function resetCollectingWager(code: string): Promise<void> {
  await transactRoom(code, (room) => {
    if (room.status === "waiting" && room.wagerStatus === "collecting") {
      room.wagerStatus = "open";
    }
    return null;
  });
}

export async function cleanupAbandonedWagers(): Promise<void> {
  const snapshot = await firebaseAdminDatabase.ref("gameRooms").get();
  const rooms = snapshot.val();
  if (!rooms || typeof rooms !== "object") return;

  const now = Date.now();
  for (const [code, value] of Object.entries(rooms)) {
    if (!value || typeof value !== "object") continue;
    const room = value as Room;
    const lastActivityAt = Number(room.lastActivityAt ?? room.createdAt ?? 0);

    if (
      room.status === "waiting" &&
      room.betAmount > 0 &&
      room.wagerStatus === "open" &&
      now - lastActivityAt >= wagerInactivityLimitMs
    ) {
      const expired = await transactRoom(code, (current) => {
        const currentActivityAt = Number(current.lastActivityAt ?? current.createdAt ?? 0);
        if (
          current.status !== "waiting" ||
          current.betAmount <= 0 ||
          current.wagerStatus !== "open" ||
          now - currentActivityAt < wagerInactivityLimitMs
        ) {
          return null;
        }
        current.status = "cancelled";
        current.lastActivityAt = now;
        return null;
      });
      if (expired.room?.status === "cancelled" && expired.room.wagerStatus === "open") {
        await roomRef(code).remove();
        logger.info({ roomCode: code }, "Expired an inactive open challenge");
      }
    } else if (
      room.status === "playing" &&
      room.wagerStatus === "escrowed" &&
      now - lastActivityAt >= wagerInactivityLimitMs
    ) {
      const cancelled = await transactRoom(code, (current) => {
        if (
          current.status !== "playing" ||
          current.wagerStatus !== "escrowed" ||
          now - Number(current.lastActivityAt ?? current.createdAt ?? 0) < wagerInactivityLimitMs
        ) {
          return null;
        }
        current.status = "cancelled";
        current.currentPlayerId = null;
        current.dice = null;
        current.lastActivityAt = now;
        return null;
      });
      if (cancelled.room?.status === "cancelled") {
        logger.info({ roomCode: code }, "Canceling an inactive wagered match and refunding stakes");
      }
    }

    try {
      const latestSnapshot = await roomRef(code).get();
      if (latestSnapshot.exists()) {
        const latest = latestSnapshot.val() as Room;
        if (
          latest.status === "finished" ||
          latest.status === "cancelled"
        ) {
          await reconcileRoomWager(latest);
        }
      }
    } catch (error) {
      logger.error({ err: error, roomCode: code }, "Wager recovery will be retried");
    }
  }
}

router.use(requireFirebaseAuth);

router.get("/challenges", async (req, res): Promise<void> => {
  try {
    const uid = getFirebaseUid(req);
    const now = Date.now();
    const snapshot = await firebaseAdminDatabase.ref("gameRooms").get();
    const rooms = snapshot.val();
    const challenges = Object.values(rooms ?? {})
      .filter((value): value is Room => !!value && typeof value === "object")
      .filter((room) =>
        room.status === "waiting" &&
        room.wagerStatus === "open" &&
        Number(room.betAmount) > 0 &&
        now - Number(room.lastActivityAt ?? room.createdAt ?? 0) < wagerInactivityLimitMs &&
        Array.isArray(room.players) &&
        room.players.length === 1
      )
      .map((room) => ({
        id: room.code,
        hostName: room.players.find((player) => player.id === room.hostId)?.name ?? "Ludo player",
        betAmount: room.betAmount,
        createdAt: Number(room.createdAt ?? room.lastActivityAt ?? 0),
        isMine: room.players.some((player) => player.id === room.hostId && player.uid === uid),
      }))
      .sort((first, second) => second.createdAt - first.createdAt);

    res.json(GetChallengesResponse.parse(challenges));
  } catch (error) {
    sendUnexpectedError(res, error);
  }
});

router.post("/challenges", async (req, res): Promise<void> => {
  const parsed = CreateChallengeBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const betAmount = parsed.data.betAmount;
  if (betAmount <= 0) {
    res.status(400).json({ error: "A challenge must have a stake greater than zero." });
    return;
  }
  try {
    toPaise(betAmount);
    const code = await makeCode();
    const uid = getFirebaseUid(req);
    const host: Player = {
      id: makeId("player"),
      uid,
      name: parsed.data.playerName.trim(),
      color: colors[0],
      tokens: [0, 0, 0, 0],
    };
    const room: Room = {
      code,
      hostId: host.id,
      status: "waiting",
      currentPlayerId: null,
      dice: null,
      winnerId: null,
      players: [host],
      betAmount,
      wagerStatus: betAmount > 0 ? "open" : "none",
      potAmount: 0,
      commissionAmount: null,
      winnerPayout: null,
      createdAt: Date.now(),
      lastActivityAt: Date.now(),
    };

    const created = await roomRef(code).transaction(
      (current) => (current === null ? room : undefined),
      undefined,
      false,
    );
    if (!created.committed) {
      res.status(503).json({ error: "Could not create a unique challenge. Try again." });
      return;
    }
    res.status(201).json(CreateChallengeResponse.parse(publicRoom(room, uid)));
  } catch (error) {
    sendUnexpectedError(res, error);
  }
});

router.get("/rooms/:code", async (req, res): Promise<void> => {
  const params = GetRoomParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  try {
    const snapshot = await roomRef(params.data.code).get();
    if (!snapshot.exists()) {
      res.status(404).json({ error: "Room not found" });
      return;
    }
    const rawRoom = snapshot.val() as Room;
    const uid = getFirebaseUid(req);
    if (!rawRoom.players.some((player) => player.uid === uid)) {
      res.status(403).json({ error: "This signed-in account is not a player in this match." });
      return;
    }
    const room = await reconcileRoomWager(rawRoom);
    res.json(GetRoomResponse.parse(publicRoom(room, uid)));
  } catch (error) {
    if (error instanceof WagerError && error.status === 404) {
      res.status(404).json({ error: error.message });
      return;
    }
    sendUnexpectedError(res, error);
  }
});

router.post("/challenges/:challengeId/join", async (req, res): Promise<void> => {
  const params = JoinChallengeParams.safeParse(req.params);
  const body = JoinChallengeBody.safeParse(req.body);
  if (!params.success || !body.success) {
    res.status(400).json({
      error: !params.success
        ? params.error.message
        : body.success
          ? "Invalid request body"
          : body.error.message,
    });
    return;
  }

  try {
    const acceptedPaise = toPaise(body.data.acceptedBetAmount);
    const uid = getFirebaseUid(req);
    const player: Player = {
      id: makeId("player"),
      uid,
      name: body.data.playerName.trim(),
      color: colors[0],
      tokens: [0, 0, 0, 0],
    };
    const { room, failure } = await transactRoom(params.data.challengeId, (current) => {
      if (
        current.status !== "waiting" ||
        current.betAmount <= 0 ||
        current.wagerStatus !== "open" ||
        current.players.length !== 1
      ) {
        return { status: 400, message: "This challenge is no longer open." };
      }
      if (current.players.some((existing) => existing.uid === uid)) {
        return { status: 409, message: "You created this challenge and cannot join it." };
      }
      if (current.players.length >= 2) {
        return { status: 400, message: "This challenge already has an opponent." };
      }
      if (acceptedPaise !== toPaise(current.betAmount)) {
        return {
          status: 409,
          message: "The challenge stake changed. Review the current amount before joining.",
        };
      }
      player.color = colors[current.players.length];
      current.players.push(player);
      current.lastActivityAt = Date.now();
      return null;
    });
    if (failure || !room) {
      sendFailure(res, failure);
      return;
    }
    res.json(JoinChallengeResponse.parse(publicRoom(room, uid)));
  } catch (error) {
    sendUnexpectedError(res, error);
  }
});

router.post("/rooms/:code/start", async (req, res): Promise<void> => {
  const params = StartRoomParams.safeParse(req.params);
  const body = StartRoomBody.safeParse(req.body);
  if (!params.success || !body.success) {
    res.status(400).json({
      error: !params.success
        ? params.error.message
        : body.success
          ? "Invalid request body"
          : body.error.message,
    });
    return;
  }

  const uid = getFirebaseUid(req);
  try {
    const locked = await transactRoom(params.data.code, (room) => {
      const host = room.players.find((player) => player.id === body.data.playerId);
      if (!host || host.uid !== uid || room.hostId !== host.id) {
        return { status: 403, message: "Only the signed-in host can start this match." };
      }
      if (room.status === "playing") return null;
      if (room.status !== "waiting") {
        return { status: 400, message: "This room cannot be started." };
      }
      if (room.players.length !== 2) {
        return { status: 400, message: "A head-to-head match needs exactly two players to start." };
      }
      if (room.betAmount > 0) {
        if (!["open", "collecting", "escrowed"].includes(room.wagerStatus)) {
          return { status: 409, message: "This table's wager cannot be collected." };
        }
        if (room.wagerStatus === "open") room.wagerStatus = "collecting";
      }
      return null;
    });
    if (locked.failure || !locked.room) {
      sendFailure(res, locked.failure);
      return;
    }

    let wagerResult: WagerResult | null = null;
    const roomBeforeStart = locked.room;
    if (roomBeforeStart.status !== "playing" && roomBeforeStart.betAmount > 0) {
      const kycStatuses = await Promise.all(
        roomBeforeStart.players.map(async (player) =>
          (await firebaseAdminDatabase.ref("kyc").child(player.uid).child("status").get()).val(),
        ),
      );
      if (kycStatuses.some((status) => status !== "approved")) {
        if (roomBeforeStart.wagerStatus === "escrowed") {
          await refundWager(roomBeforeStart.code);
          await transactRoom(roomBeforeStart.code, (room) => {
            if (room.status === "waiting" && room.wagerStatus === "escrowed") {
              room.status = "cancelled";
              room.wagerStatus = "refunded";
            }
            return null;
          });
        } else {
          await resetCollectingWager(roomBeforeStart.code);
        }
        res.status(400).json({
          error: "Every player needs approved KYC before a wagered match can start.",
        });
        return;
      }

      wagerResult = await collectWager(
        roomBeforeStart.code,
        roomBeforeStart.betAmount,
        roomBeforeStart.players.map(({ id, uid: playerUid, name }) => ({
          id,
          uid: playerUid,
          name,
        })),
      );
    }

    const started = await transactRoom(params.data.code, (room) => {
      const host = room.players.find((player) => player.id === body.data.playerId);
      if (!host || host.uid !== uid || room.hostId !== host.id) {
        return { status: 403, message: "Only the signed-in host can start this match." };
      }
      if (room.status === "playing") return null;
      if (room.status !== "waiting") {
        return { status: 400, message: "This room cannot be started." };
      }
      if (room.betAmount > 0 && room.wagerStatus !== "collecting" && room.wagerStatus !== "escrowed") {
        return { status: 409, message: "The table stake is not ready to be escrowed." };
      }
      room.status = "playing";
      room.currentPlayerId = room.players[0]?.id ?? null;
      room.dice = null;
      room.lastActivityAt = Date.now();
      if (room.betAmount > 0) {
        const amounts = wagerResult ?? calculateWagerAmounts(room.betAmount, room.players.length);
        room.wagerStatus = "escrowed";
        room.potAmount = amounts.potAmount;
        room.commissionAmount = amounts.commissionAmount;
        room.winnerPayout = amounts.winnerPayout;
      }
      return null;
    });
    if (started.failure || !started.room) {
      sendFailure(res, started.failure);
      return;
    }
    res.json(StartRoomResponse.parse(publicRoom(started.room, uid)));
  } catch (error) {
    if (error instanceof WagerError && error.status === 402) {
      await resetCollectingWager(params.data.code).catch(() => undefined);
    }
    sendUnexpectedError(res, error);
  }
});

router.post("/rooms/:code/roll", async (req, res): Promise<void> => {
  const params = RollDiceParams.safeParse(req.params);
  const body = RollDiceBody.safeParse(req.body);
  if (!params.success || !body.success) {
    res.status(400).json({
      error: !params.success
        ? params.error.message
        : body.success
          ? "Invalid request body"
          : body.error.message,
    });
    return;
  }

  const uid = getFirebaseUid(req);
  const rolled = Math.floor(Math.random() * 6) + 1;
  try {
    const { room, failure } = await transactRoom(params.data.code, (current) => {
      const player = current.players.find((candidate) => candidate.id === body.data.playerId);
      if (!player || player.uid !== uid) {
        return { status: 403, message: "This player does not belong to your signed-in account." };
      }
      if (current.status !== "playing" || current.currentPlayerId !== body.data.playerId) {
        return { status: 400, message: "It is not your turn." };
      }
      if (current.dice !== null) {
        return { status: 400, message: "Choose a token before rolling again." };
      }
      current.dice = rolled;
      current.lastActivityAt = Date.now();
      const hasLegalMove = player.tokens.some(
        (token) => rolled === 6 || (token > 0 && token < 57 && token + rolled <= 57),
      );
      if (!hasLegalMove) {
        current.dice = null;
        const currentIndex = current.players.findIndex(
          (candidate) => candidate.id === current.currentPlayerId,
        );
        current.currentPlayerId =
          current.players[(currentIndex + 1) % current.players.length]?.id ?? null;
      }
      return null;
    });
    if (failure || !room) {
      sendFailure(res, failure);
      return;
    }
    res.json(RollDiceResponse.parse(publicRoom(room, uid)));
  } catch (error) {
    sendUnexpectedError(res, error);
  }
});

router.post("/rooms/:code/move", async (req, res): Promise<void> => {
  const params = MoveTokenParams.safeParse(req.params);
  const body = MoveTokenBody.safeParse(req.body);
  if (!params.success || !body.success) {
    res.status(400).json({
      error: !params.success
        ? params.error.message
        : body.success
          ? "Invalid request body"
          : body.error.message,
    });
    return;
  }

  const uid = getFirebaseUid(req);
  try {
    const { room, failure } = await transactRoom(params.data.code, (current) => {
      const playerIndex = current.players.findIndex(
        (candidate) => candidate.id === body.data.playerId,
      );
      const player = current.players[playerIndex];
      if (!player || player.uid !== uid) {
        return { status: 403, message: "This player does not belong to your signed-in account." };
      }
      if (current.status !== "playing" || current.currentPlayerId !== body.data.playerId) {
        return { status: 400, message: "It is not your turn." };
      }
      if (current.dice === null) {
        return { status: 400, message: "Roll the dice first." };
      }

      const tokenIndex = body.data.tokenIndex;
      const currentPosition = player.tokens[tokenIndex];
      if (currentPosition === 0 && current.dice !== 6) {
        return { status: 400, message: "A six is needed to bring a token out." };
      }

      const rolledSix = current.dice === 6;
      player.tokens[tokenIndex] =
        currentPosition === 0 ? 1 : Math.min(57, currentPosition + current.dice);
      current.dice = null;
      current.lastActivityAt = Date.now();

      if (player.tokens.every((token) => token >= 57)) {
        current.status = "finished";
        current.winnerId = player.id;
        current.currentPlayerId = null;
      } else if (!rolledSix) {
        current.currentPlayerId =
          current.players[(playerIndex + 1) % current.players.length]?.id ?? null;
      }
      return null;
    });
    if (failure || !room) {
      sendFailure(res, failure);
      return;
    }

    let latestRoom = room;
    if (room.status === "finished" && room.betAmount > 0 && room.winnerId) {
      try {
        latestRoom = await reconcileRoomWager(room);
      } catch (error) {
        logger.error({ err: error, roomCode: room.code }, "Winner settlement will be retried");
      }
    }
    res.json(MoveTokenResponse.parse(publicRoom(latestRoom, uid)));
  } catch (error) {
    sendUnexpectedError(res, error);
  }
});

router.delete("/rooms/:code", async (req, res): Promise<void> => {
  const params = DeleteRoomParams.safeParse(req.params);
  const body = DeleteRoomBody.safeParse(req.body);
  if (!params.success || !body.success) {
    res.status(400).json({
      error: !params.success
        ? params.error.message
        : body.success
          ? "Invalid request body"
          : body.error.message,
    });
    return;
  }

  const uid = getFirebaseUid(req);
  try {
    const { room, failure } = await transactRoom(params.data.code, (current) => {
      const player = current.players.find((candidate) => candidate.id === body.data.playerId);
      if (!player || player.uid !== uid) {
        return { status: 403, message: "This player does not belong to your signed-in account." };
      }
      if (current.status === "finished" || current.status === "cancelled") return null;
      if (
        current.status === "playing" ||
        (current.betAmount > 0 && current.wagerStatus === "escrowed")
      ) {
        current.status = "cancelled";
        current.currentPlayerId = null;
        current.dice = null;
        current.lastActivityAt = Date.now();
        return null;
      }
      if (current.wagerStatus === "collecting") {
        return { status: 409, message: "Stakes are being collected. Wait a moment before leaving." };
      }
      if (body.data.playerId === current.hostId) {
        current.status = "cancelled";
        return null;
      }
      current.players = current.players.filter(
        (candidate) => candidate.id !== body.data.playerId,
      );
      current.players.forEach((candidate, index) => {
        candidate.color = colors[index];
      });
      current.lastActivityAt = Date.now();
      return null;
    });
    if (failure) {
      sendFailure(res, failure);
      return;
    }
    if (!room) {
      res.status(404).json({ error: "Room not found" });
      return;
    }

    if (room.status === "cancelled" && room.wagerStatus === "escrowed") {
      await refundWager(room.code);
      await markWagerResult(room.code, "refunded");
    } else if (room.status === "cancelled" && room.wagerStatus === "open") {
      await roomRef(room.code).remove();
    } else if (room.status === "cancelled" && room.wagerStatus === "none") {
      await roomRef(room.code).remove();
    }

    res.sendStatus(204);
  } catch (error) {
    sendUnexpectedError(res, error);
  }
});

export default router;