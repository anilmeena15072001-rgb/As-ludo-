import { firebaseAdminDatabase } from "./firebase-admin";

type WagerParticipant = {
  id: string;
  name: string;
  uid: string;
};

type LedgerParticipant = WagerParticipant & { stakeCents: number };

type WagerLedger = {
  status: "escrowed" | "settled" | "refunded";
  roomCode: string;
  stakeCents: number;
  potCents: number;
  commissionCents: number;
  payoutCents: number;
  participants: LedgerParticipant[];
  winnerPlayerId?: string;
  createdAt: number;
  settledAt?: number;
  refundedAt?: number;
};

export type WagerResult = {
  potAmount: number;
  commissionAmount: number;
  winnerPayout: number;
};

export class WagerError extends Error {
  constructor(
    message: string,
    readonly status = 400,
  ) {
    super(message);
    this.name = "WagerError";
  }
}

function isObject(value: unknown): value is Record<string, any> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

export function toPaise(amount: number): number {
  if (!Number.isFinite(amount) || amount < 0) {
    throw new WagerError("Enter a valid stake amount.");
  }
  const paise = Math.round(amount * 100);
  if (!Number.isSafeInteger(paise)) {
    throw new WagerError("The stake amount is too large to process safely.");
  }
  if (Math.abs(amount * 100 - paise) > 0.000001) {
    throw new WagerError("Stake amounts can have at most two decimal places.");
  }
  return paise;
}

function balanceInPaise(wallet: unknown): number {
  const raw =
    typeof wallet === "number"
      ? wallet
      : isObject(wallet)
        ? Number(wallet.balance ?? 0)
        : 0;
  if (!Number.isFinite(raw) || raw < 0) {
    throw new WagerError("A wallet balance is invalid. Contact support before starting this match.", 409);
  }
  const paise = Math.round(raw * 100);
  if (!Number.isSafeInteger(paise)) {
    throw new WagerError("A wallet balance is too large to process safely.", 409);
  }
  return paise;
}

function writeWallet(
  wallets: Record<string, any>,
  uid: string,
  balanceCents: number,
  roomCode: string,
  entry: Record<string, unknown>,
) {
  const current = wallets[uid];
  const wallet = isObject(current) ? current : {};
  const wagerEntries = isObject(wallet.wagers) ? wallet.wagers : {};
  wallets[uid] = {
    ...wallet,
    balance: balanceCents / 100,
    wagers: {
      ...wagerEntries,
      [roomCode]: entry,
    },
  };
}

async function transactWallets<T>(
  update: (wallets: Record<string, any>) =>
    | { value: T }
    | { error: string; status: number },
): Promise<T> {
  let failure: { error: string; status: number } | null = null;
  let resultValue: T;

  const result = await firebaseAdminDatabase.ref("wallets").transaction(
    (current) => {
      failure = null;
      const wallets = isObject(current) ? current : {};
      const outcome = update(wallets);
      if ("error" in outcome) {
        failure = outcome;
        return;
      }
      resultValue = outcome.value;
      return wallets;
    },
    undefined,
    false,
  );

  if (!result.committed) {
    const transactionFailure = failure as { error: string; status: number } | null;
    if (transactionFailure) {
      throw new WagerError(transactionFailure.error, transactionFailure.status);
    }
    throw new WagerError("Wallet transaction could not be completed. No wager was changed.", 503);
  }

  return resultValue!;
}

function getLedger(wallets: Record<string, any>, roomCode: string): WagerLedger | null {
  const system = isObject(wallets.__roomLudoSystem) ? wallets.__roomLudoSystem : {};
  const ledgers = isObject(system.wagers) ? system.wagers : {};
  const ledger = ledgers[roomCode];
  return isObject(ledger) ? (ledger as WagerLedger) : null;
}

function setLedger(wallets: Record<string, any>, roomCode: string, ledger: WagerLedger) {
  const system = isObject(wallets.__roomLudoSystem) ? wallets.__roomLudoSystem : {};
  const ledgers = isObject(system.wagers) ? system.wagers : {};
  wallets.__roomLudoSystem = {
    ...system,
    wagers: { ...ledgers, [roomCode]: ledger },
  };
}

function resultFromLedger(ledger: WagerLedger): WagerResult {
  return {
    potAmount: ledger.potCents / 100,
    commissionAmount: ledger.commissionCents / 100,
    winnerPayout: ledger.payoutCents / 100,
  };
}

export async function collectWager(
  roomCode: string,
  betAmount: number,
  participants: WagerParticipant[],
): Promise<WagerResult> {
  const stakeCents = toPaise(betAmount);
  if (stakeCents <= 0 || participants.length < 2) {
    throw new WagerError("A wager requires a positive stake and at least two players.");
  }
  if (new Set(participants.map((participant) => participant.uid)).size !== participants.length) {
    throw new WagerError("Each player must use a separate account to join a wagered match.");
  }

  const potCents = stakeCents * participants.length;
  if (!Number.isSafeInteger(potCents)) {
    throw new WagerError("The total pot is too large to process safely.");
  }
  const commissionCents = Math.round(potCents * 0.05);
  const payoutCents = potCents - commissionCents;

  return transactWallets<WagerResult>((wallets) => {
    const existing = getLedger(wallets, roomCode);
    if (existing) {
      const sameParticipants =
        existing.stakeCents === stakeCents &&
        existing.participants.length === participants.length &&
        participants.every((participant) =>
          existing.participants.some(
            (entry) => entry.id === participant.id && entry.uid === participant.uid,
          ),
        );
      if (!sameParticipants) {
        return { error: "This room already has a different wager record.", status: 409 };
      }
      if (existing.status === "escrowed") return { value: resultFromLedger(existing) };
      return { error: "This room's wager is no longer open.", status: 409 };
    }

    for (const participant of participants) {
      let currentBalance: number;
      try {
        currentBalance = balanceInPaise(wallets[participant.uid]);
      } catch (error) {
        return {
          error: error instanceof Error ? error.message : "A wallet balance is invalid.",
          status: error instanceof WagerError ? error.status : 409,
        };
      }
      if (currentBalance < stakeCents) {
        return {
          error: `${participant.name} does not have enough wallet balance for the ₹${(stakeCents / 100).toFixed(2)} stake.`,
          status: 402,
        };
      }
    }

    const ledgerParticipants = participants.map((participant) => ({
      ...participant,
      stakeCents,
    }));

    for (const participant of ledgerParticipants) {
      const currentBalance = balanceInPaise(wallets[participant.uid]);
      writeWallet(
        wallets,
        participant.uid,
        currentBalance - stakeCents,
        roomCode,
        { type: "stake", amount: stakeCents / 100, status: "escrowed", createdAt: Date.now() },
      );
    }

    setLedger(wallets, roomCode, {
      status: "escrowed",
      roomCode,
      stakeCents,
      potCents,
      commissionCents,
      payoutCents,
      participants: ledgerParticipants,
      createdAt: Date.now(),
    });

    return {
      value: {
        potAmount: potCents / 100,
        commissionAmount: commissionCents / 100,
        winnerPayout: payoutCents / 100,
      },
    };
  });
}

export async function settleWager(
  roomCode: string,
  winnerPlayerId: string,
): Promise<WagerResult> {
  return transactWallets<WagerResult>((wallets) => {
    const ledger = getLedger(wallets, roomCode);
    if (!ledger) return { error: "The escrow record for this match is missing.", status: 409 };
    if (ledger.status === "settled") {
      if (ledger.winnerPlayerId !== winnerPlayerId) {
        return { error: "This match already has a different settled winner.", status: 409 };
      }
      return { value: resultFromLedger(ledger) };
    }
    if (ledger.status !== "escrowed") {
      return { error: "This wager cannot be settled because it is no longer escrowed.", status: 409 };
    }

    const winner = ledger.participants.find((participant) => participant.id === winnerPlayerId);
    if (!winner) return { error: "The winner is not part of this wager.", status: 409 };

    for (const participant of ledger.participants) {
      if (participant.id === winnerPlayerId) continue;
      const balance = balanceInPaise(wallets[participant.uid]);
      writeWallet(
        wallets,
        participant.uid,
        balance,
        roomCode,
        {
          type: "stake_loss",
          amount: participant.stakeCents / 100,
          status: "settled",
          createdAt: Date.now(),
        },
      );
    }

    const winnerBalance = balanceInPaise(wallets[winner.uid]);
    writeWallet(
      wallets,
      winner.uid,
      winnerBalance + ledger.payoutCents,
      roomCode,
      {
        type: "winner_payout",
        amount: ledger.payoutCents / 100,
        status: "settled",
        createdAt: Date.now(),
      },
    );

    const system = isObject(wallets.__roomLudoSystem) ? wallets.__roomLudoSystem : {};
    const currentCommission = Number(system.commissionCents ?? 0);
    if (!Number.isSafeInteger(currentCommission) || currentCommission < 0) {
      return { error: "The platform commission record is invalid.", status: 409 };
    }
    if (!Number.isSafeInteger(currentCommission + ledger.commissionCents)) {
      return { error: "The platform commission total is too large to process safely.", status: 409 };
    }
    wallets.__roomLudoSystem = {
      ...system,
      commissionCents: currentCommission + ledger.commissionCents,
    };

    const settledLedger: WagerLedger = {
      ...ledger,
      status: "settled",
      winnerPlayerId,
      settledAt: Date.now(),
    };
    setLedger(wallets, roomCode, settledLedger);
    return { value: resultFromLedger(settledLedger) };
  });
}

export async function refundWager(roomCode: string): Promise<void> {
  await transactWallets<void>((wallets) => {
    const ledger = getLedger(wallets, roomCode);
    if (!ledger) {
      return { error: "The escrow record for this match is missing.", status: 409 };
    }
    if (ledger.status === "refunded") return { value: undefined };
    if (ledger.status !== "escrowed") {
      return { error: "A settled wager cannot be refunded.", status: 409 };
    }

    for (const participant of ledger.participants) {
      const currentBalance = balanceInPaise(wallets[participant.uid]);
      writeWallet(
        wallets,
        participant.uid,
        currentBalance + participant.stakeCents,
        roomCode,
        {
          type: "stake_refund",
          amount: participant.stakeCents / 100,
          status: "refunded",
          createdAt: Date.now(),
        },
      );
    }

    setLedger(wallets, roomCode, { ...ledger, status: "refunded", refundedAt: Date.now() });
    return { value: undefined };
  });
}

export function calculateWagerAmounts(betAmount: number, playerCount: number): WagerResult {
  const stakeCents = toPaise(betAmount);
  const potCents = stakeCents * playerCount;
  const commissionCents = Math.round(potCents * 0.05);
  return {
    potAmount: potCents / 100,
    commissionAmount: commissionCents / 100,
    winnerPayout: (potCents - commissionCents) / 100,
  };
}