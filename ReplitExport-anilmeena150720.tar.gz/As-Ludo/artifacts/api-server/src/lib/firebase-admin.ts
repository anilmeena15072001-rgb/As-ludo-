import { cert, getApps, initializeApp } from "firebase-admin/app";
import { getAuth } from "firebase-admin/auth";
import { getDatabase } from "firebase-admin/database";

const serviceAccountJson = process.env.FIREBASE_SERVICE_ACCOUNT_JSON;

if (!serviceAccountJson) {
  throw new Error("FIREBASE_SERVICE_ACCOUNT_JSON must be configured for the API server.");
}

let serviceAccount: Record<string, unknown>;
try {
  serviceAccount = JSON.parse(serviceAccountJson) as Record<string, unknown>;
} catch {
  throw new Error("FIREBASE_SERVICE_ACCOUNT_JSON must contain valid JSON.");
}

const projectId =
  typeof serviceAccount.project_id === "string" ? serviceAccount.project_id : "";

if (!projectId || typeof serviceAccount.private_key !== "string" || typeof serviceAccount.client_email !== "string") {
  throw new Error("FIREBASE_SERVICE_ACCOUNT_JSON is missing required service-account fields.");
}

const appName = "room-ludo-api";
const app =
  getApps().find((candidate) => candidate.name === appName) ??
  initializeApp(
    {
      credential: cert(serviceAccount as Parameters<typeof cert>[0]),
      databaseURL:
        process.env.FIREBASE_DATABASE_URL ??
        "https://ludo-zone-d7b9f-default-rtdb.firebaseio.com",
    },
    appName,
  );

export const firebaseAdminAuth = getAuth(app);
export const firebaseAdminDatabase = getDatabase(app);