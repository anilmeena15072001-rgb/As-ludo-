---
name: Firebase security boundary
description: The Room Ludo client uses Firebase Web SDK for auth and Realtime Database, with rules required for wallet and KYC protection.
---

Firebase web configuration is safe to ship in the browser, but client-side phone checks are not an authorization boundary. Wallet writes and admin-only KYC status changes must be enforced by Realtime Database Rules or a trusted server.

**Why:** Users can inspect and modify browser JavaScript, so hiding an admin button or checking a phone number in React alone cannot protect balances or approvals.

**How to apply:** Keep the admin phone check for UX, and deploy the companion Firebase rules whenever wallet, KYC, or withdrawal data is used.

In the Replit preview, Firebase may log that reCAPTCHA Enterprise initialization failed before falling back to invisible reCAPTCHA v2. Treat that fallback log as informational; the actionable failure is the Firebase auth error returned by the OTP request.

**Why:** The preview environment can differ from Firebase's Enterprise reCAPTCHA configuration while v2 still provides the required app verification.

**How to apply:** Keep the v2 `RecaptchaVerifier` path enabled and diagnose the displayed `auth/*` error code plus message for actual OTP failures.