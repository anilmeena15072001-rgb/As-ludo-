---
name: Generated client DOM iterable
description: A TypeScript lib setting needed by generated fetch helpers in this workspace.
---

Generated API client code reads `Headers.entries()`, so packages that typecheck the generated client must include both `dom` and `dom.iterable` in their TypeScript `lib`.

**Why:** The generated client otherwise compiles with a missing `Headers.entries` error even though the browser runtime supports it.

**How to apply:** Preserve `dom.iterable` in the API client package compiler options when regenerating the client.